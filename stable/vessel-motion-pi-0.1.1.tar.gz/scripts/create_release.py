from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a Vessel Motion OTA release")
    parser.add_argument("version")
    parser.add_argument("--output", type=Path, default=ROOT / "dist" / "ota")
    parser.add_argument(
        "--base-url",
        default="https://raw.githubusercontent.com/barba-productions/vessel-motion-pi-OTA/main/stable",
    )
    args = parser.parse_args()
    version_file = ROOT / "src" / "vessel_motion" / "__init__.py"
    expected = f'__version__ = "{args.version}"'
    if expected not in version_file.read_text(encoding="utf-8"):
        raise SystemExit(f"Version does not match {version_file}")
    args.output.mkdir(parents=True, exist_ok=True)
    archive = args.output / f"vessel-motion-pi-{args.version}.tar.gz"
    include = ("src", "web", "config", "deploy", "scripts", "pyproject.toml", "requirements.txt", "README.md")
    with tarfile.open(archive, "w:gz", format=tarfile.PAX_FORMAT) as package:
        for name in include:
            path = ROOT / name
            if path.exists():
                package.add(path, arcname=name, recursive=True)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    manifest = {
        "schema": 1,
        "product": "vessel-motion-pi",
        "channel": "stable",
        "version": args.version,
        "architecture": "aarch64",
        "url": f"{args.base_url.rstrip('/')}/{archive.name}",
        "size": archive.stat().st_size,
        "sha256": digest,
    }
    (args.output / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    (args.output / f"{archive.name}.sha256").write_text(
        f"{digest}  {archive.name}\n", encoding="ascii"
    )
    print(f"Created {archive}")


if __name__ == "__main__":
    main()
