from __future__ import annotations

import ctypes
from dataclasses import dataclass
import importlib
import os
import struct
import threading
import time
from typing import Any

from .motion import AxisMap, G0, Vector3

fcntl: Any | None
try:
    fcntl = importlib.import_module("fcntl")
except ImportError:
    fcntl = None

I2C_RDWR = 0x0707
I2C_M_RD = 1


class I2CMessage(ctypes.Structure):
    _fields_ = [
        ("addr", ctypes.c_uint16),
        ("flags", ctypes.c_uint16),
        ("length", ctypes.c_uint16),
        ("buffer", ctypes.c_void_p),
    ]


class I2CTransfer(ctypes.Structure):
    _fields_ = [("messages", ctypes.POINTER(I2CMessage)), ("count", ctypes.c_uint32)]


class LinuxI2C:
    def __init__(self, bus: int, address: int) -> None:
        if fcntl is None:
            raise OSError("Linux I2C is only available on the Raspberry Pi")
        self.address = address
        self.fd = os.open(
            f"/dev/i2c-{bus}", os.O_RDWR | int(getattr(os, "O_CLOEXEC", 0))
        )

    def close(self) -> None:
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1

    def _transfer(self, messages: ctypes.Array[I2CMessage], count: int) -> None:
        driver = fcntl
        if driver is None:
            raise OSError("Linux I2C is only available on the Raspberry Pi")
        driver.ioctl(self.fd, I2C_RDWR, I2CTransfer(messages, count))

    def write(self, register: int, value: int) -> None:
        output = ctypes.create_string_buffer(bytes((register, value)))
        messages = (I2CMessage * 1)(
            I2CMessage(self.address, 0, 2, ctypes.addressof(output))
        )
        self._transfer(messages, 1)

    def read(self, register: int, length: int) -> bytes:
        output = ctypes.create_string_buffer(bytes((register,)))
        incoming = ctypes.create_string_buffer(length)
        messages = (I2CMessage * 2)(
            I2CMessage(self.address, 0, 1, ctypes.addressof(output)),
            I2CMessage(self.address, I2C_M_RD, length, ctypes.addressof(incoming)),
        )
        self._transfer(messages, 2)
        return incoming.raw


@dataclass(slots=True)
class SensorSample:
    timestamp_ns: int
    accel_uncalibrated: Vector3
    gyro_uncalibrated: Vector3
    accel_sensor: Vector3
    accel_vessel: Vector3
    gyro: Vector3
    temperature_raw: int


class MPU6050:
    SUPPORTED_IDENTITIES = {0x68: "MPU-6050", 0x74: "MPU-6515-compatible"}

    def __init__(
        self,
        bus: int,
        address: int,
        axis_map: AxisMap | None = None,
        accel_offset: Vector3 | None = None,
        gyro_offset: Vector3 | None = None,
    ) -> None:
        self.io = LinuxI2C(bus, address)
        self.axis_map = axis_map or AxisMap()
        self.accel_offset = accel_offset or Vector3()
        self.gyro_offset = gyro_offset or Vector3()
        self.identity = self.io.read(0x75, 1)[0]
        if self.identity not in self.SUPPORTED_IDENTITIES:
            self.close()
            raise RuntimeError(f"Unsupported IMU identity 0x{self.identity:02x}")
        for register, value in ((0x19, 0), (0x1A, 0), (0x1B, 0x08), (0x1C, 0), (0x6B, 1)):
            self.io.write(register, value)
        time.sleep(0.1)
        for register, expected in ((0x19, 0), (0x1A, 0), (0x1B, 8), (0x1C, 0), (0x6B, 1)):
            actual = self.io.read(register, 1)[0]
            if actual != expected:
                self.close()
                raise RuntimeError(
                    f"IMU register 0x{register:02x}: expected {expected}, got {actual}"
                )
        self.previous_raw: tuple[int, ...] | None = None
        self.unchanged_samples = 0

    @property
    def model(self) -> str:
        return self.SUPPORTED_IDENTITIES[self.identity]

    def close(self) -> None:
        self.io.close()

    def read(self) -> SensorSample:
        raw = struct.unpack(">7h", self.io.read(0x3B, 14))
        if raw == self.previous_raw:
            self.unchanged_samples += 1
        else:
            self.unchanged_samples = 0
        self.previous_raw = raw
        if self.unchanged_samples >= 400:
            raise RuntimeError("All IMU channels have been frozen for two seconds")
        accel = Vector3(*(raw[index] * G0 / 16384.0 for index in range(3)))
        if any(abs(value) > 2.1 * G0 for value in (accel.x, accel.y, accel.z)):
            raise RuntimeError("IMU acceleration sample exceeded the configured range")
        gyro = Vector3(*(raw[index] * 3.141592653589793 / (65.5 * 180.0) for index in range(4, 7)))
        accel_uncalibrated = accel
        gyro_uncalibrated = gyro
        accel = accel_uncalibrated - self.accel_offset
        gyro = gyro_uncalibrated - self.gyro_offset
        return SensorSample(
            time.monotonic_ns(),
            accel_uncalibrated,
            gyro_uncalibrated,
            accel,
            self.axis_map.apply(accel),
            self.axis_map.apply_axial(gyro),
            raw[3],
        )


class SensorWorker:
    def __init__(self, factory, sample_hz: int, callback) -> None:
        self.factory = factory
        self.sample_hz = sample_hz
        self.callback = callback
        self.stop_event = threading.Event()
        self.thread: threading.Thread | None = None
        self.sensor: MPU6050 | None = None
        self.errors = self.invalid = self.missed = 0
        self.sample_hz_actual = 0.0
        self.online = False

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._run, name="motion-200hz", daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=3)

    def _run(self) -> None:
        period_ns = int(1_000_000_000 / self.sample_hz)
        while not self.stop_event.is_set():
            try:
                sensor = self.factory()
                self.sensor = sensor
                self.online = True
                next_sample = time.monotonic_ns()
                measured_at, count = next_sample, 0
                while not self.stop_event.is_set():
                    sample = sensor.read()
                    self.callback(sample)
                    count += 1
                    now = time.monotonic_ns()
                    if now - measured_at >= 1_000_000_000:
                        self.sample_hz_actual = count * 1_000_000_000 / (now - measured_at)
                        measured_at, count = now, 0
                    next_sample += period_ns
                    delay_ns = next_sample - time.monotonic_ns()
                    if delay_ns > 0:
                        time.sleep(delay_ns / 1_000_000_000)
                    else:
                        self.missed += 1
                        next_sample = time.monotonic_ns()
            except (OSError, RuntimeError):
                self.errors += 1
                self.online = False
                if self.sensor:
                    self.sensor.close()
                    self.sensor = None
                self.stop_event.wait(0.25)
        if self.sensor:
            self.sensor.close()
        self.online = False
