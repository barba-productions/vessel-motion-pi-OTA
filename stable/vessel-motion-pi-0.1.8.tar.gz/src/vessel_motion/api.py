from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager, suppress
from datetime import datetime, timezone
import json
from pathlib import Path
import struct
import time
from urllib.parse import parse_qs

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from . import __version__
from .config import load_config
from .service import VesselMotionService
from .storage import Storage
from .system import ClockManager, NetworkManager, WifiManager
from .updater import UpdateManager


def render_shared_header(content: str, web_dir: Path, dashboard: bool) -> str:
    header = (web_dir / "_header.html").read_text(encoding="utf-8")
    attribute = "data-view" if dashboard else "data-dashboard-view"
    routes = {
        "overview": "overview",
        "attitude": "attitude",
        "trends": "trends" if dashboard else "trends/acceleration",
        "heatmap": "heatmap",
        "trip_history": "trip-history",
    }
    for name, route in routes.items():
        active = 'class="active" ' if dashboard and name == "overview" else ""
        header = header.replace(
            "{{" + name + "_attributes}}",
            f'{active}{attribute}="{route}"',
        )
    header = header.replace(
        "{{connection_id}}", "dashboardConnection" if dashboard else "settingsConnection"
    ).replace(
        "{{status_dot_id}}", "statusDot" if dashboard else "settingsStatusDot"
    )
    return content.replace("{{shared_header}}", header)


def create_app() -> FastAPI:
    config = load_config()
    config.kiosk_unlock_file.unlink(missing_ok=True)
    storage = Storage(config.data_dir, config.trip_retention)
    motion = VesselMotionService(config, storage)
    wifi, network = WifiManager(), NetworkManager()
    clock, updater = ClockManager(), UpdateManager(config)
    failed_unlocks: dict[str, list[float]] = {}

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        async def monitor_wifi() -> None:
            while True:
                try:
                    await asyncio.to_thread(
                        wifi.ensure_fallback_if_needed,
                        bool(storage.settings().get("wifiAuto", True)),
                    )
                except (OSError, RuntimeError):
                    pass
                await asyncio.sleep(5)

        motion.start()
        wifi_monitor = asyncio.create_task(monitor_wifi())
        try:
            yield
        finally:
            wifi_monitor.cancel()
            with suppress(asyncio.CancelledError):
                await wifi_monitor
            motion.stop()

    app = FastAPI(title="Vessel Motion", version=__version__, lifespan=lifespan)
    app.state.config = config
    app.state.storage = storage
    app.state.motion = motion

    @app.get("/health")
    def health() -> dict[str, object]:
        return {
            "status": "ok" if motion.worker.online else "degraded",
            "sensor": motion.worker.online,
            "version": __version__,
            "rtc": Path("/dev/rtc0").exists(),
        }

    @app.get("/")
    def index() -> HTMLResponse:
        content = (config.web_dir / "index.html").read_text(encoding="utf-8")
        content = render_shared_header(content, config.web_dir, dashboard=True)
        for asset in ("app.css", "large-type.css", "header.css", "app.js"):
            content = content.replace(f'"/{asset}"', f'"/{asset}?v={__version__}"')
        return HTMLResponse(content, headers={"Cache-Control": "no-store"})

    @app.get("/advanced-settings")
    @app.get("/settings")
    def settings_page(request: Request) -> HTMLResponse:
        content = (config.web_dir / "settings.html").read_text(encoding="utf-8")
        content = content.replace(
            '<option value="original" selected="selected">ORIGINAL</option>', ""
        ).replace(
            '<option value="tug">TUG</option>',
            '<option value="tug" selected="selected">TUG</option>',
        ).replace(
            '<h3 id="modelProfileTitle">ORIGINAL MODEL VIEW</h3>',
            '<h3 id="modelProfileTitle">TUG MODEL VIEW</h3>',
        )
        for key in ("Scale", "Vertical", "Elevation", "Yaw"):
            content = content.replace(
                f'<input type="hidden" name="original{key}" value="100">'
                if key == "Scale"
                else f'<input type="hidden" name="original{key}" value="0">',
                "",
            )
        topbar_start = content.index('<div class="topbar">')
        settings_tabs_start = content.index(
            '<nav class="settings-tabs"', topbar_start
        )
        content = (
            content[:topbar_start]
            + '<div class="topbar">{{shared_header}}</div>'
            + content[settings_tabs_start:]
        )
        content = render_shared_header(content, config.web_dir, dashboard=False)
        content = content.replace(
            "</head>",
            f'<link rel="stylesheet" href="/header.css?v={__version__}"></head>',
        )
        scripts = (
            '<script src="/settings-pi.js"></script>'
            if request.url.path == "/settings"
            else ""
        ) + (
            '<script>addEventListener("DOMContentLoaded",function(){'
            'if(location.pathname==="/advanced-settings")'
            'document.querySelectorAll("[data-tab=general],[data-tab=motion],'
            '[data-panel=general],[data-panel=motion]").forEach(function(e){e.remove()});'
            'var s=document.querySelector(\'select[name="vesselModel"]\');'
            'if(s&&!s.querySelector(\'option[value="superyacht"]\')){'
            'var o=document.createElement("option");o.value="superyacht";'
            'o.textContent="SUPERYACHT";s.appendChild(o)}})</script>'
        )
        return HTMLResponse(content.replace("</body>", scripts + "</body>"))

    @app.post("/advanced-settings")
    @app.post("/settings")
    async def save_settings_page(
        request: Request, background_tasks: BackgroundTasks
    ) -> RedirectResponse:
        form = {
            key: values[-1]
            for key, values in parse_qs((await request.body()).decode("utf-8")).items()
        }
        existing = storage.settings()
        parsed: dict[str, object] = {}
        for key, value in form.items():
            if key not in existing:
                continue
            current = existing[key]
            if isinstance(current, bool):
                parsed[key] = value.lower() in ("1", "true", "yes", "on")
            elif isinstance(current, int):
                parsed[key] = int(float(value))
            elif isinstance(current, float):
                parsed[key] = float(value)
            else:
                parsed[key] = value
        storage.update_settings(parsed)
        if {"dhcp", "ip", "subnet", "gateway", "dns"} & parsed.keys():
            background_tasks.add_task(network.apply_ethernet, storage.settings())
        motion.apply_settings()
        destination = (
            "/advanced-settings"
            if form.get("returnTo") == "advanced"
            else "/settings"
        )
        active_tab = form.get("activeTab", "")
        if active_tab.replace("-", "").isalnum():
            destination += "?tab=" + active_tab + "#" + active_tab
        return RedirectResponse(destination, status_code=303)

    @app.get("/diagnostics")
    def diagnostics() -> FileResponse:
        return FileResponse(config.web_dir / "diagnostics.html")

    @app.get("/theme.js")
    def theme() -> Response:
        settings = storage.settings()
        selected = {
            key: settings[key] for key in (
                "productName", "productSize", "uiFont", "colorScheme", "fullscreen",
                "vessel", "vesselModel", "timezone", "hideKioskCursor",
            )
        }
        selected.update({
            key: settings[key] for key in (
                "tugScale", "tugVertical", "tugElevation", "tugYaw",
                "yachtScale", "yachtVertical", "yachtElevation", "yachtYaw",
                "superyachtScale", "superyachtVertical", "superyachtElevation", "superyachtYaw",
                "garminRefresh", "reloadOnTab",
            )
        })
        return Response(
            "window.vmUiSettings=" + json.dumps(selected, separators=(",", ":")) + ";",
            media_type="application/javascript",
            headers={"Cache-Control": "no-store"},
        )

    @app.get("/api/telemetry")
    def telemetry() -> dict[str, object]:
        return motion.telemetry()

    @app.websocket("/ws")
    async def websocket(websocket: WebSocket) -> None:
        import asyncio
        await websocket.accept()
        period = 1 / config.telemetry_hz
        try:
            while True:
                await websocket.send_json(motion.telemetry())
                try:
                    message = await asyncio.wait_for(websocket.receive_text(), timeout=period)
                    motion.command(message)
                except asyncio.TimeoutError:
                    pass
        except WebSocketDisconnect:
            return

    @app.post("/api/command", status_code=204)
    async def command(request: Request) -> Response:
        try:
            motion.command((await request.body()).decode("utf-8"))
        except (ValueError, RuntimeError) as error:
            raise HTTPException(409, str(error)) from error
        return Response(status_code=204)

    @app.get("/api/settings")
    def get_settings() -> dict[str, object]:
        values = storage.settings()
        values.update({
            "algorithmVersion": motion.algorithm.version,
            "garminRefresh": 20,
            "graphSeconds": 600,
            "smoothing": 0.15,
            "legacy": False,
        })
        return values

    @app.patch("/api/settings")
    async def patch_settings(
        request: Request, background_tasks: BackgroundTasks
    ) -> dict[str, object]:
        try:
            values = await request.json()
            if not isinstance(values, dict):
                raise ValueError("Settings payload must be an object")
            storage.update_settings(values)
            if {"dhcp", "ip", "subnet", "gateway", "dns"} & values.keys():
                background_tasks.add_task(network.apply_ethernet, storage.settings())
            if "timezone" in values:
                clock.set_timezone(str(values["timezone"]))
            motion.apply_settings()
            return storage.settings()
        except (ValueError, RuntimeError) as error:
            raise HTTPException(400, str(error)) from error

    @app.get("/api/trips")
    def trips() -> dict[str, object]:
        return {
            "trips": storage.list_trips(),
            "maximum": config.trip_retention,
            "sampleIntervalSeconds": 1 / config.trip_sample_hz,
            "maximumDurationSeconds": config.maximum_trip_seconds,
        }

    @app.get("/api/trip/detail")
    def trip_detail(id: int) -> dict[str, object]:
        result = storage.trip_detail(id)
        if result is None:
            raise HTTPException(404, "Trip not found")
        return result

    @app.get("/api/trip/samples")
    def trip_samples(id: int) -> Response:
        result = storage.trip_samples_binary(id)
        if result is None:
            raise HTTPException(404, "Trip not found")
        return Response(result, media_type="application/octet-stream")

    @app.get("/api/trip/current")
    def current_trip() -> dict[str, object]:
        trip = storage.active_trip()
        return {"active": False} if trip is None else {
            "active": True, "id": trip["id"], "durationSeconds": trip["duration_seconds"],
            "samples": trip["sample_count"], "headerBytes": 0,
            "sampleIntervalSeconds": 1 / config.trip_sample_hz,
            "startMs": trip["start_ms"], "label": trip["label"],
        }

    @app.get("/api/trip/current-samples")
    def current_trip_samples() -> Response:
        if storage.active_trip() is None:
            raise HTTPException(404, "No active trip")
        result = storage.current_trip_samples_binary()
        return Response(
            result,
            media_type="application/octet-stream",
            headers={"X-Trip-Samples": str(len(result) // 16), "Cache-Control": "no-store"},
        )

    @app.get("/api/trip/heatmap")
    def heatmap() -> Response:
        trip_id, active, values = motion.heatmap_snapshot()
        header = struct.pack("<BBHIf", 1, 1 if active else 0, 400, trip_id, sum(values))
        return Response(header + struct.pack("<400f", *values), media_type="application/octet-stream")

    @app.get("/api/overview-samples")
    def overview_samples() -> Response:
        current_ms, samples, impacts = motion.overview_snapshot()
        header = struct.pack(
            "<8sHHHHHHI",
            b"VMOVR2\0\0", 2, 24, len(samples), 2, len(impacts), 0, current_ms,
        )
        body = b"".join(struct.pack("<I6h", *sample) for sample in samples)
        body += b"".join(struct.pack("<I", impact) for impact in impacts)
        return Response(
            header + body,
            media_type="application/octet-stream",
            headers={"Cache-Control": "no-store"},
        )

    @app.delete("/api/history", status_code=204)
    def clear_history() -> Response:
        if not storage.clear_history():
            raise HTTPException(409, "Stop the active trip before clearing history")
        return Response(status_code=204)

    @app.get("/api/wifi/status")
    def wifi_status() -> dict[str, object]:
        try:
            return wifi.status()
        except RuntimeError as error:
            raise HTTPException(503, str(error)) from error

    @app.get("/api/wifi/scan")
    def wifi_scan() -> dict[str, object]:
        try:
            return {"networks": wifi.scan()}
        except RuntimeError as error:
            raise HTTPException(503, str(error)) from error

    @app.post("/api/wifi/connect", status_code=202)
    async def wifi_connect(request: Request) -> dict[str, bool]:
        try:
            body = await request.json()
        except json.JSONDecodeError:
            body = {}
        try:
            wifi.connect(str(body.get("ssid", "")), str(body.get("password", "")))
            return {"connecting": True}
        except (ValueError, RuntimeError) as error:
            raise HTTPException(409, str(error)) from error

    @app.post("/api/wifi/disconnect")
    def wifi_disconnect() -> dict[str, bool]:
        try:
            wifi.disconnect()
            return {"connected": False}
        except RuntimeError as error:
            raise HTTPException(409, str(error)) from error

    @app.post("/api/wifi/clear")
    def wifi_forget() -> dict[str, bool]:
        try:
            wifi.clear()
            return {"connected": False, "credentials": False}
        except RuntimeError as error:
            raise HTTPException(409, str(error)) from error

    @app.get("/api/time")
    def time_status() -> dict[str, object]:
        return clock.status(str(storage.settings()["timezone"]))

    @app.get("/api/timezones")
    def timezones() -> dict[str, list[str]]:
        return {"timezones": clock.timezones()}

    @app.put("/api/time")
    async def set_time(request: Request) -> dict[str, object]:
        body = await request.json()
        try:
            if "timezone" in body:
                clock.set_timezone(str(body["timezone"]))
                storage.update_settings({"timezone": str(body["timezone"])})
            if body.get("localTime"):
                clock.set_time(
                    str(body["localTime"]), str(storage.settings()["timezone"])
                )
            return clock.status(str(storage.settings()["timezone"]))
        except (ValueError, RuntimeError) as error:
            raise HTTPException(400, str(error)) from error

    @app.post("/api/time")
    async def set_time_compatibility(request: Request) -> dict[str, object]:
        try:
            epoch_ms = int((await request.body()).decode("ascii"))
            value = datetime.fromtimestamp(epoch_ms / 1000, timezone.utc).isoformat()
            zone_name = str(storage.settings()["timezone"])
            clock.set_time(value, zone_name)
            return clock.status(zone_name)
        except (ValueError, RuntimeError) as error:
            raise HTTPException(400, str(error)) from error

    @app.get("/api/export/trips.csv")
    def export_trips() -> Response:
        return Response(
            storage.trips_csv(),
            media_type="text/csv",
            headers={"Content-Disposition": 'attachment; filename="trip-history.csv"'},
        )

    @app.get("/api/export/impacts.csv")
    def export_impacts() -> Response:
        return Response(
            storage.impacts_csv(),
            media_type="text/csv",
            headers={"Content-Disposition": 'attachment; filename="impact-events.csv"'},
        )

    @app.get("/garmin/config.json")
    def garmin_config() -> dict[str, str]:
        return {
            "id": "vessel-motion-pi",
            "path": "/web2/screen.html",
            "title": "Vessel Motion",
            "icon": "/web2/garmin.png",
        }

    @app.get("/api/ota/status")
    def update_status() -> dict[str, object]:
        return updater.snapshot()

    @app.post("/api/ota/start", status_code=202)
    def update_start() -> dict[str, object]:
        if not updater.start():
            raise HTTPException(409, "An update is already running")
        return updater.snapshot()

    @app.post("/api/maintenance/unlock", status_code=204)
    async def maintenance_unlock(request: Request) -> Response:
        host = request.client.host if request.client else "unknown"
        now = time.monotonic()
        attempts = [item for item in failed_unlocks.get(host, []) if now - item < 300]
        if len(attempts) >= 5:
            raise HTTPException(429, "Too many incorrect PIN attempts")
        body = await request.json()
        if not storage.verify_pin(str(body.get("pin", ""))):
            attempts.append(now)
            failed_unlocks[host] = attempts
            raise HTTPException(403, "Incorrect maintenance PIN")
        config.kiosk_unlock_file.parent.mkdir(parents=True, exist_ok=True)
        config.kiosk_unlock_file.write_text(str(int(time.time())), encoding="ascii")
        failed_unlocks.pop(host, None)
        return Response(status_code=204)

    @app.put("/api/maintenance/pin", status_code=204)
    async def maintenance_pin(request: Request) -> Response:
        body = await request.json()
        try:
            storage.set_pin(str(body.get("oldPin", "")), str(body.get("newPin", "")))
        except (ValueError, PermissionError) as error:
            raise HTTPException(400, str(error)) from error
        return Response(status_code=204)

    app.mount("/", StaticFiles(directory=config.web_dir), name="web")
    return app
