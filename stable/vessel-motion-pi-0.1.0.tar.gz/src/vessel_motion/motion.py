from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
import math
import time

G0 = 9.80665


def clamp(value: float, low: float, high: float) -> float:
    return low if value < low else high if value > high else value


def normalize(value: float, low: float, high: float, exponent: float) -> float:
    if high <= low:
        return 1.0 if value >= high else 0.0
    return clamp((value - low) / (high - low), 0.0, 1.0) ** exponent


@dataclass(slots=True)
class Vector3:
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

    def magnitude(self) -> float:
        return math.sqrt(self.x * self.x + self.y * self.y + self.z * self.z)

    def __sub__(self, other: Vector3) -> Vector3:
        return Vector3(self.x - other.x, self.y - other.y, self.z - other.z)


@dataclass(slots=True)
class AxisMap:
    source: tuple[int, int, int] = (0, 1, 2)
    sign: tuple[int, int, int] = (1, -1, 1)

    def __post_init__(self) -> None:
        if sorted(self.source) != [0, 1, 2] or any(value not in (-1, 1) for value in self.sign):
            raise ValueError("Axis mapping must use each source axis once with signs of -1 or 1")

    def apply(self, value: Vector3) -> Vector3:
        values = (value.x, value.y, value.z)
        return Vector3(*(values[self.source[i]] * self.sign[i] for i in range(3)))

    def determinant(self) -> int:
        inversions = sum(
            self.source[i] > self.source[j] for i in range(3) for j in range(i + 1, 3)
        )
        return (-1 if inversions & 1 else 1) * math.prod(self.sign)

    def apply_axial(self, value: Vector3) -> Vector3:
        mapped = self.apply(value)
        orientation = self.determinant()
        return Vector3(mapped.x * orientation, mapped.y * orientation, mapped.z * orientation)


@dataclass(slots=True)
class RangeConfig:
    low: float
    high: float
    exponent: float = 2.0


@dataclass(slots=True)
class AlgorithmConfig:
    version: int = 1
    complementary_alpha: float = 0.98
    fast_cutoff_hz: float = 25.0
    slow_cutoff_hz: float = 4.0
    derivative_cutoff_hz: float = 12.0
    peak: RangeConfig = field(default_factory=lambda: RangeConfig(0.10, 1.50))
    rms: RangeConfig = field(default_factory=lambda: RangeConfig(0.03, 0.50))
    jerk: RangeConfig = field(default_factory=lambda: RangeConfig(0.5, 15.0))
    roll_rate: RangeConfig = field(default_factory=lambda: RangeConfig(2.0, 25.0))
    pitch_rate: RangeConfig = field(default_factory=lambda: RangeConfig(2.0, 25.0))
    repeat: RangeConfig = field(default_factory=lambda: RangeConfig(1.0, 20.0))
    rsi_weights: tuple[float, ...] = (0.35, 0.25, 0.20, 0.10, 0.10)
    rsi_attack_seconds: float = 0.20
    rsi_decay_seconds: float = 5.0
    impact_start_g: float = 0.25
    impact_end_g: float = 0.15
    impact_end_ms: int = 100
    impact_deadband_ms: int = 150
    impact_accel: RangeConfig = field(default_factory=lambda: RangeConfig(0.25, 1.50))
    impact_jerk: RangeConfig = field(default_factory=lambda: RangeConfig(1.0, 15.0))
    mei_axis_weights: tuple[float, float, float] = (1.0, 1.0, 1.0)
    mei_rms: RangeConfig = field(default_factory=lambda: RangeConfig(0.02, 0.30))
    mei_shock: RangeConfig = field(default_factory=lambda: RangeConfig(0.03, 0.50))
    mei_duration_tau_hours: float = 4.0
    mei_current_weights: tuple[float, float, float] = (0.45, 0.35, 0.20)


@dataclass(slots=True)
class Orientation:
    roll: float = 0.0
    pitch: float = 0.0
    display_roll: float = 0.0
    display_pitch: float = 0.0
    gravity: Vector3 = field(default_factory=Vector3)


class OrientationFilter:
    def __init__(self) -> None:
        self.roll = self.pitch = self.roll_zero = self.pitch_zero = 0.0
        self.initialized = False

    def reset(self, accel: Vector3) -> None:
        self.roll = math.atan2(accel.y, accel.z)
        self.pitch = math.atan2(-accel.x, math.sqrt(accel.y**2 + accel.z**2))
        self.initialized = True

    def update(self, accel: Vector3, gyro: Vector3, dt: float, alpha: float) -> Orientation:
        if not self.initialized:
            self.reset(accel)
        roll_acc = math.atan2(accel.y, accel.z)
        pitch_acc = math.atan2(-accel.x, math.sqrt(accel.y**2 + accel.z**2))
        if 0.0 < dt <= 0.05:
            self.roll = alpha * (self.roll + gyro.x * dt) + (1 - alpha) * roll_acc
            self.pitch = alpha * (self.pitch + gyro.y * dt) + (1 - alpha) * pitch_acc
        return Orientation(
            self.roll,
            self.pitch,
            self.roll - self.roll_zero,
            self.pitch - self.pitch_zero,
            Vector3(
                -G0 * math.sin(self.pitch),
                G0 * math.sin(self.roll) * math.cos(self.pitch),
                G0 * math.cos(self.roll) * math.cos(self.pitch),
            ),
        )

    def zero(self) -> None:
        self.roll_zero, self.pitch_zero = self.roll, self.pitch


class LowPass3:
    def __init__(self) -> None:
        self.state = Vector3()

    def update(self, value: Vector3, cutoff: float, dt: float) -> Vector3:
        alpha = dt / (1.0 / (2.0 * math.pi * cutoff) + dt)
        self.state.x += alpha * (value.x - self.state.x)
        self.state.y += alpha * (value.y - self.state.y)
        self.state.z += alpha * (value.z - self.state.z)
        return Vector3(self.state.x, self.state.y, self.state.z)


@dataclass(slots=True)
class Motion:
    linear: Vector3 = field(default_factory=Vector3)
    fast: Vector3 = field(default_factory=Vector3)
    slow: Vector3 = field(default_factory=Vector3)
    jerk: Vector3 = field(default_factory=Vector3)
    fast_resultant: float = 0.0
    slow_resultant: float = 0.0
    jerk_resultant: float = 0.0
    roll_rate: float = 0.0
    pitch_rate: float = 0.0
    accel_peak: float = 0.0
    accel_rms: float = 0.0
    jerk_peak: float = 0.0
    roll_rate_peak: float = 0.0
    pitch_rate_peak: float = 0.0


class MotionAnalyzer:
    def __init__(self, window: int = 200) -> None:
        self.fast_filter, self.slow_filter, self.jerk_filter = LowPass3(), LowPass3(), LowPass3()
        self.previous_fast = Vector3()
        self.accel = deque(maxlen=window)
        self.jerk = deque(maxlen=window)
        self.roll = deque(maxlen=window)
        self.pitch = deque(maxlen=window)

    def update(
        self, accel: Vector3, gravity: Vector3, gyro: Vector3, dt: float, cfg: AlgorithmConfig
    ) -> Motion:
        linear = accel - gravity
        fast = self.fast_filter.update(linear, cfg.fast_cutoff_hz, dt)
        slow = self.slow_filter.update(linear, cfg.slow_cutoff_hz, dt)
        raw_jerk = Vector3(
            (fast.x - self.previous_fast.x) / dt,
            (fast.y - self.previous_fast.y) / dt,
            (fast.z - self.previous_fast.z) / dt,
        )
        jerk = self.jerk_filter.update(raw_jerk, cfg.derivative_cutoff_hz, dt)
        self.previous_fast = fast
        values = (fast.magnitude(), jerk.magnitude(), abs(gyro.x), abs(gyro.y))
        for target, value in zip((self.accel, self.jerk, self.roll, self.pitch), values):
            target.append(value)
        rms = math.sqrt(sum(value * value for value in self.accel) / len(self.accel))
        return Motion(
            linear, fast, slow, jerk, values[0], slow.magnitude(), values[1], gyro.x, gyro.y,
            max(self.accel), rms, max(self.jerk), max(self.roll), max(self.pitch),
        )


@dataclass(slots=True)
class Severity:
    peak: float = 0.0
    rms: float = 0.0
    jerk: float = 0.0
    angular: float = 0.0
    repeat: float = 0.0
    raw: float = 0.0
    current: float = 0.0


class RideSeverity:
    def __init__(self) -> None:
        self.state = Severity()

    def update(self, motion: Motion, impacts_per_minute: float, dt: float, cfg: AlgorithmConfig) -> Severity:
        ranges = (
            (motion.accel_peak / G0, cfg.peak),
            (motion.accel_rms / G0, cfg.rms),
            (motion.jerk_peak / G0, cfg.jerk),
        )
        peak, rms, jerk = (normalize(value, item.low, item.high, item.exponent) for value, item in ranges)
        angular = max(
            normalize(math.degrees(motion.roll_rate_peak), cfg.roll_rate.low, cfg.roll_rate.high, cfg.roll_rate.exponent),
            normalize(math.degrees(motion.pitch_rate_peak), cfg.pitch_rate.low, cfg.pitch_rate.high, cfg.pitch_rate.exponent),
        )
        repeat = normalize(impacts_per_minute, cfg.repeat.low, cfg.repeat.high, cfg.repeat.exponent)
        raw = 10.0 * clamp(sum(w * v for w, v in zip(cfg.rsi_weights, (peak, rms, jerk, angular, repeat))), 0, 1)
        tau = cfg.rsi_attack_seconds if raw > self.state.current else cfg.rsi_decay_seconds
        current = self.state.current + (1 - math.exp(-dt / max(tau, 0.001))) * (raw - self.state.current)
        self.state = Severity(peak, rms, jerk, angular, repeat, raw, current)
        return self.state


@dataclass(slots=True)
class Exposure:
    sum_a2: float = 0.0
    dose4: float = 0.0
    seconds: float = 0.0
    rms: float = 0.0
    shock: float = 0.0
    current: float = 0.0


class MotionExposure:
    def __init__(self) -> None:
        self.state = Exposure()
        self.recent_a2 = self.recent_dose4 = self.recent_seconds = 0.0

    def update(self, slow: Vector3, dt: float, active: bool, cfg: AlgorithmConfig) -> Exposure:
        effective = math.sqrt(sum((w * v) ** 2 for w, v in zip(
            cfg.mei_axis_weights, (slow.x, slow.y, slow.z)
        )))
        if active:
            self.state.sum_a2 += effective * effective * dt
            self.state.dose4 += effective**4 * dt
            self.state.seconds += dt
            decay = math.exp(-dt / 600.0)
            self.recent_a2 = self.recent_a2 * decay + effective * effective * dt
            self.recent_dose4 = self.recent_dose4 * decay + effective**4 * dt
            self.recent_seconds = self.recent_seconds * decay + dt
        recent_rms = math.sqrt(self.recent_a2 / self.recent_seconds) if self.recent_seconds else 0
        recent_shock = (self.recent_dose4 / self.recent_seconds) ** 0.25 if self.recent_seconds else 0
        self.state.rms = normalize(recent_rms / G0, cfg.mei_rms.low, cfg.mei_rms.high, cfg.mei_rms.exponent)
        self.state.shock = normalize(recent_shock / G0, cfg.mei_shock.low, cfg.mei_shock.high, cfg.mei_shock.exponent)
        duration = 1 - math.exp(-(self.recent_seconds / 3600) / cfg.mei_duration_tau_hours)
        self.state.current = 10 * clamp(sum(w * v for w, v in zip(
            cfg.mei_current_weights, (self.state.rms, self.state.shock, duration)
        )), 0, 1)
        return self.state


@dataclass(slots=True)
class Impact:
    start_ms: int
    end_ms: int
    duration_ms: int
    peak: Vector3
    peak_resultant: float
    peak_jerk: float
    roll: float
    pitch: float
    rsi: float
    severity: float


class ImpactDetector:
    def __init__(self) -> None:
        self.active = False
        self.below_since = self.last_end = 0
        self.current: Impact | None = None
        self.recent: deque[tuple[int, float]] = deque(maxlen=64)

    def weighted_per_minute(self, now_ms: int) -> float:
        return sum(severity for at, severity in self.recent if now_ms - at <= 60_000)

    def update(
        self, motion: Motion, orientation: Orientation, rsi: float, now_ms: int, cfg: AlgorithmConfig
    ) -> Impact | None:
        acceleration_g = motion.fast_resultant / G0
        if not self.active and acceleration_g >= cfg.impact_start_g and now_ms - self.last_end >= cfg.impact_deadband_ms:
            self.active = True
            self.below_since = 0
            self.current = Impact(now_ms, 0, 0, motion.fast, motion.fast_resultant, motion.jerk_resultant,
                                  orientation.display_roll, orientation.display_pitch, rsi, 0)
        if not self.active or self.current is None:
            return None
        if motion.fast_resultant >= self.current.peak_resultant:
            self.current.peak = motion.fast
            self.current.peak_resultant = motion.fast_resultant
            self.current.roll = orientation.display_roll
            self.current.pitch = orientation.display_pitch
            self.current.rsi = rsi
        self.current.peak_jerk = max(self.current.peak_jerk, motion.jerk_resultant)
        if acceleration_g > cfg.impact_end_g:
            self.below_since = 0
            return None
        if not self.below_since:
            self.below_since = now_ms
            return None
        if now_ms - self.below_since < cfg.impact_end_ms:
            return None
        self.current.end_ms = now_ms
        self.current.duration_ms = now_ms - self.current.start_ms
        accel_score = normalize(self.current.peak_resultant / G0, cfg.impact_accel.low,
                                cfg.impact_accel.high, cfg.impact_accel.exponent)
        jerk_score = normalize(self.current.peak_jerk / G0, cfg.impact_jerk.low,
                               cfg.impact_jerk.high, cfg.impact_jerk.exponent)
        self.current.severity = clamp(0.75 * accel_score + 0.25 * jerk_score, 0, 1)
        completed = self.current
        self.recent.append((now_ms, completed.severity))
        self.active, self.last_end, self.current = False, now_ms, None
        return completed


def monotonic_ms() -> int:
    return time.monotonic_ns() // 1_000_000
