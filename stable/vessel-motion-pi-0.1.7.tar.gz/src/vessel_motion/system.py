from __future__ import annotations

from datetime import datetime
from ipaddress import IPv4Address, IPv4Network
from pathlib import Path
import re
import subprocess
import time
from typing import TypedDict
from zoneinfo import available_timezones, ZoneInfo


class WifiNetwork(TypedDict):
    ssid: str
    rssi: int
    secure: bool


FALLBACK_AP_CONNECTION = "vessel-motion-fallback-ap"
FALLBACK_AP_SSID = "Vessel-Motion"


def _device(device_type: str) -> str:
    output = run_command(["nmcli", "-t", "-f", "DEVICE,TYPE", "device", "status"])
    for line in output.splitlines():
        device, current_type = line.split(":", 1)
        if current_type == device_type:
            return device
    raise RuntimeError(f"No {device_type} adapter is available")


class NetworkManager:
    def apply_ethernet(self, settings: dict[str, object]) -> None:
        device = _device("ethernet")
        connection = run_command([
            "nmcli", "-g", "GENERAL.CONNECTION", "device", "show", device,
        ]).strip()
        if not connection or connection == "--":
            raise RuntimeError("Ethernet does not have a NetworkManager connection")
        arguments = ["nmcli", "connection", "modify", connection]
        if bool(settings.get("dhcp", True)):
            arguments.extend((
                "ipv4.method", "auto", "ipv4.addresses", "",
                "ipv4.gateway", "", "ipv4.dns", "",
            ))
        else:
            address = str(IPv4Address(str(settings.get("ip", ""))))
            subnet = str(settings.get("subnet", ""))
            prefix = IPv4Network(f"0.0.0.0/{subnet}").prefixlen
            gateway = str(settings.get("gateway", "")).strip()
            dns = str(settings.get("dns", "")).strip()
            if gateway:
                IPv4Address(gateway)
            if dns:
                IPv4Address(dns)
            arguments.extend((
                "ipv4.method", "manual", "ipv4.addresses", f"{address}/{prefix}",
                "ipv4.gateway", gateway, "ipv4.dns", dns,
            ))
        run_command(arguments)
        run_command(["nmcli", "connection", "up", connection], timeout=45)


def run_command(arguments: list[str], timeout: int = 20) -> str:
    completed = subprocess.run(
        arguments,
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if completed.returncode:
        message = completed.stderr.strip() or completed.stdout.strip() or "Command failed"
        raise RuntimeError(message)
    return completed.stdout


class WifiManager:
    def __init__(self) -> None:
        self._next_client_retry = time.monotonic() + 60

    def _state(self) -> tuple[str, str, str]:
        output = run_command([
            "nmcli", "-t", "-f", "TYPE,STATE,CONNECTION", "device", "status"
        ])
        return tuple(next(
            (line.split(":", 2) for line in output.splitlines() if line.startswith("wifi:")),
            ("wifi", "unavailable", ""),
        ))

    def status(self) -> dict[str, object]:
        wifi = self._state()
        access_point = wifi[2] == FALLBACK_AP_CONNECTION
        connected = wifi[1] == "connected" and not access_point
        if wifi[1] not in {"connected", "connecting"}:
            self.ensure_fallback_access_point()
            access_point = True
        details = {
            "connected": connected,
            "connecting": wifi[1] == "connecting",
            "ssid": "" if access_point else wifi[2],
            "accessPoint": access_point,
            "accessPointSsid": FALLBACK_AP_SSID,
            "accessPointAddress": "http://192.168.4.1",
        }
        if connected:
            connection = run_command([
                "nmcli", "-t", "-f", "IP4.ADDRESS,GENERAL.HWADDR",
                "device", "show",
                self._wifi_device(),
            ])
            address = next(
                (line.split(":", 1)[1].split("/", 1)[0] for line in connection.splitlines()
                 if line.startswith("IP4.ADDRESS")),
                "",
            )
            details["ip"] = address
        else:
            details["ip"] = ""
        details["internet"] = connected and run_command([
            "nmcli", "-t", "-f", "CONNECTIVITY", "general",
        ]).strip() == "full"
        return details

    def _wifi_device(self) -> str:
        return _device("wifi")

    def ensure_fallback_access_point(self) -> None:
        run_command(["nmcli", "connection", "up", FALLBACK_AP_CONNECTION], timeout=45)

    def ensure_fallback_if_needed(self, auto_connect: bool = True) -> None:
        wifi = self._state()
        if wifi[1] not in {"connected", "connecting"}:
            self.ensure_fallback_access_point()
            return
        if (
            wifi[2] != FALLBACK_AP_CONNECTION
            or not auto_connect
            or time.monotonic() < self._next_client_retry
        ):
            return
        self._next_client_retry = time.monotonic() + 60
        try:
            self._activate_preferred_client()
        except RuntimeError:
            self.ensure_fallback_access_point()

    def _activate_preferred_client(self) -> None:
        fallback_uuid = run_command([
            "nmcli", "-g", "connection.uuid", "connection", "show",
            FALLBACK_AP_CONNECTION,
        ]).strip()
        output = run_command([
            "nmcli", "-t", "-f",
            "UUID,TYPE,AUTOCONNECT,AUTOCONNECT-PRIORITY",
            "connection", "show",
        ])
        profiles: list[tuple[int, str]] = []
        for line in output.splitlines():
            parts = line.split(":", 3)
            if (
                len(parts) == 4
                and parts[0] != fallback_uuid
                and parts[1] in {"802-11-wireless", "wifi"}
                and parts[2] == "yes"
            ):
                try:
                    profiles.append((int(parts[3] or 0), parts[0]))
                except ValueError:
                    continue
        if not profiles:
            raise RuntimeError("No saved Wi-Fi client profile is available")
        _, connection_uuid = max(profiles)
        run_command([
            "nmcli", "connection", "up", "uuid", connection_uuid,
        ], timeout=45)

    def scan(self) -> list[WifiNetwork]:
        output = run_command([
            "nmcli", "-t", "--escape", "yes", "-f", "SSID,SIGNAL,SECURITY",
            "device", "wifi", "list", "--rescan", "yes",
        ], timeout=30)
        networks: dict[str, WifiNetwork] = {}
        for line in output.splitlines():
            parts = re.split(r"(?<!\\):", line)
            if len(parts) < 3:
                continue
            ssid = parts[0].replace(r"\:", ":").replace(r"\\", "\\")
            if not ssid:
                continue
            signal = int(parts[1] or 0)
            rssi = round(signal / 2 - 100)
            if ssid not in networks or rssi > networks[ssid]["rssi"]:
                networks[ssid] = {
                    "ssid": ssid,
                    "rssi": rssi,
                    "secure": bool(parts[2] and parts[2] != "--"),
                }
        return sorted(networks.values(), key=lambda item: item["rssi"], reverse=True)

    def connect(self, ssid: str, password: str) -> None:
        if not 1 <= len(ssid.encode("utf-8")) <= 32:
            raise ValueError("SSID must be between 1 and 32 bytes")
        arguments = ["nmcli", "device", "wifi", "connect", ssid, "ifname", self._wifi_device()]
        if password:
            arguments.extend(("password", password))
        run_command(arguments, timeout=45)
        run_command([
            "nmcli", "connection", "modify", "id", ssid,
            "ipv4.method", "auto", "ipv4.addresses", "",
            "ipv4.gateway", "", "ipv4.dns", "",
            "connection.autoconnect", "yes", "connection.autoconnect-priority", "100",
        ])
        run_command(["nmcli", "connection", "up", "id", ssid], timeout=45)

    def disconnect(self) -> None:
        wifi = self._state()
        if wifi[1] in {"connected", "connecting"} and wifi[2] != FALLBACK_AP_CONNECTION:
            run_command(["nmcli", "device", "disconnect", self._wifi_device()])
        self.ensure_fallback_access_point()

    def forget(self, ssid: str = "") -> None:
        if not ssid:
            ssid = str(self.status().get("ssid", ""))
        if not ssid:
            raise ValueError("There is no connected Wi-Fi network to forget")
        run_command(["nmcli", "connection", "delete", "id", ssid])

    def clear(self) -> None:
        output = run_command([
            "nmcli", "-t", "-f", "NAME,UUID,TYPE", "connection", "show",
        ])
        uuids = [
            line.split(":", 2)[1]
            for line in output.splitlines()
            if len(line.split(":", 2)) == 3
            and line.rsplit(":", 1)[-1] in {"802-11-wireless", "wifi"}
            and line.split(":", 1)[0] != FALLBACK_AP_CONNECTION
        ]
        for uuid in uuids:
            run_command(["nmcli", "connection", "delete", "uuid", uuid])
        self.ensure_fallback_access_point()


class ClockManager:
    def timezones(self) -> list[str]:
        return sorted(available_timezones())

    def status(self, timezone_name: str) -> dict[str, object]:
        zone = ZoneInfo(timezone_name)
        now = datetime.now(zone)
        return {
            "timezone": timezone_name,
            "localTime": now.isoformat(timespec="seconds"),
            "current": now.isoformat(timespec="seconds"),
            "lastSync": "RTC",
            "syncing": False,
            "epochMs": int(now.timestamp() * 1000),
            "rtc": Path("/dev/rtc0").exists(),
        }

    def set_timezone(self, timezone_name: str) -> None:
        if timezone_name not in available_timezones():
            raise ValueError("Unknown timezone")
        run_command(["timedatectl", "set-timezone", timezone_name])

    def set_time(self, iso_value: str, timezone_name: str) -> None:
        try:
            value = datetime.fromisoformat(iso_value)
        except ValueError as error:
            raise ValueError("Time must be a valid ISO-8601 value") from error
        if value.tzinfo is None:
            value = value.replace(tzinfo=ZoneInfo(timezone_name))
        else:
            value = value.astimezone(ZoneInfo(timezone_name))
        run_command(["timedatectl", "set-ntp", "false"])
        run_command(["timedatectl", "set-time", value.strftime("%Y-%m-%d %H:%M:%S")])
