from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
import logging
import math
import threading
import time
from typing import cast

from .config import AppConfig
from .motion import (
    AlgorithmConfig,
    AxisMap,
    Exposure,
    G0,
    ImpactDetector,
    Motion,
    MotionAnalyzer,
    MotionExposure,
    Orientation,
    OrientationFilter,
    RideSeverity,
    Severity,
    Vector3,
    clamp,
    monotonic_ms,
    normalize,
)
from .sensor import MPU6050, SensorSample, SensorWorker
from .storage import Storage

LOG = logging.getLogger(__name__)


def bounded_int16(value: float) -> int:
    return max(-32768, min(32767, round(value)))


@dataclass(slots=True)
class RuntimeState:
    sample: SensorSample | None = None
    orientation: Orientation = field(default_factory=Orientation)
    motion: Motion = field(default_factory=Motion)
    rsi: Severity = field(default_factory=Severity)
    mei: Exposure = field(default_factory=Exposure)
    impact: bool = False
    reset_sequence: int = 0
    last_history: tuple[int, int, int, int, int, int] = (0, 0, 0, 0, 0, 0)


@dataclass(slots=True)
class TripRuntime:
    trip_id: int = 0
    rsi_sum: float = 0.0
    rsi_updates: int = 0
    rsi_mean: float = 0.0
    rsi_max: float = 0.0
    rsi_p95: float = 0.0
    rsi_trip: float = 0.0
    mei_trip: float = 0.0
    max_roll: float = 0.0
    max_pitch: float = 0.0
    max_axis: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    max_resultant: float = 0.0
    max_jerk: float = 0.0
    weighted_impacts: float = 0.0
    impact_counts: list[int] = field(default_factory=lambda: [0, 0, 0])
    rsi_histogram: list[int] = field(default_factory=lambda: [0] * 20)
    heatmap_seconds: list[float] = field(default_factory=lambda: [0.0] * 400)
    sum_a2: float = 0.0
    dose4: float = 0.0
    exposure_seconds: float = 0.0


class VesselMotionService:
    def __init__(self, config: AppConfig, storage: Storage) -> None:
        self.config, self.storage = config, storage
        self.algorithm = AlgorithmConfig()
        self.orientation_filter = OrientationFilter()
        self.analyzer = MotionAnalyzer()
        self.severity = RideSeverity()
        self.exposure = MotionExposure()
        self.impacts = ImpactDetector()
        self.state = RuntimeState()
        self.lock = threading.RLock()
        self.last_sample_ns = 0
        self.last_severity_ns = 0
        self.last_trip_sample_ns = 0
        self.last_overview_sample_ns = 0
        self.overview_history: deque[tuple[int, int, int, int, int, int, int]] = deque()
        self.overview_impacts: deque[int] = deque(maxlen=256)
        self.overview_impact_active = False
        self.idle_seconds = 0.0
        self.idle = False
        self.rsi_enabled = True
        self.mei_enabled = True
        self.recent_calibration: deque[SensorSample] = deque(maxlen=1000)
        active_trip = storage.active_trip()
        self.active_trip_id = int(active_trip["id"]) if active_trip else None
        self.active_trip_start_ms = int(active_trip["start_ms"]) if active_trip else 0
        recovered_elapsed_ms = storage.active_trip_elapsed_ms() if active_trip else 0
        self.active_trip_start_ns = time.monotonic_ns() - recovered_elapsed_ms * 1_000_000
        self.last_trip_sample_ns = (
            self.active_trip_start_ns + recovered_elapsed_ms * 1_000_000
            if active_trip else 0
        )
        self.trip = TripRuntime(trip_id=self.active_trip_id or 0)
        settings = storage.settings()
        axis_source = cast(list[object], settings["axisSource"])
        axis_sign = cast(list[object], settings["axisSign"])
        self.axis_map = AxisMap(
            (to_int(axis_source[0]), to_int(axis_source[1]), to_int(axis_source[2])),
            (to_int(axis_sign[0]), to_int(axis_sign[1]), to_int(axis_sign[2])),
        )
        self.orientation_filter.roll_zero = to_float(settings["rollZero"])
        self.orientation_filter.pitch_zero = to_float(settings["pitchZero"])
        self.apply_settings(settings)
        self.worker = SensorWorker(self._sensor_factory, config.sample_hz, self._sample)

    def apply_settings(self, settings: dict[str, object] | None = None) -> None:
        settings = settings or self.storage.settings()
        axis_values = [to_int(settings.get(name, default)) for name, default in (
            ("axisX", 1), ("axisY", 2), ("axisZ", 3)
        )]
        if all(1 <= abs(value) <= 3 for value in axis_values) and len(
            {abs(value) for value in axis_values}
        ) == 3:
            mounting_sign = (1, -1, 1)
            sources = tuple(abs(value) - 1 for value in axis_values)
            signs = tuple(
                (1 if value > 0 else -1) * mounting_sign[source]
                for value, source in zip(axis_values, sources)
            )
            self.axis_map = AxisMap(
                (sources[0], sources[1], sources[2]),
                (signs[0], signs[1], signs[2]),
            )
        cfg = self.algorithm
        self.rsi_enabled = bool(settings["rsi"])
        self.mei_enabled = bool(settings["mei"])
        cfg.complementary_alpha = to_float(settings["alpha"])
        cfg.fast_cutoff_hz = to_float(settings["fast"])
        cfg.slow_cutoff_hz = to_float(settings["slow"])
        cfg.derivative_cutoff_hz = to_float(settings["derivative"])
        cfg.impact_start_g = to_float(settings["impactStart"])
        cfg.impact_end_g = to_float(settings["impactEnd"])
        cfg.impact_end_ms = to_int(settings["impactEndMs"])
        cfg.impact_deadband_ms = to_int(settings["impactDeadbandMs"])
        exponent = to_float(settings["exponent"])
        for target, low_key, high_key in (
            (cfg.peak, "peakLow", "peakHigh"), (cfg.rms, "rmsLow", "rmsHigh"),
            (cfg.jerk, "jerkLow", "jerkHigh"), (cfg.roll_rate, "rollLow", "rollHigh"),
            (cfg.pitch_rate, "pitchLow", "pitchHigh"), (cfg.repeat, "repeatLow", "repeatHigh"),
            (cfg.impact_accel, "impactLow", "impactHigh"),
        ):
            target.low, target.high, target.exponent = (
                to_float(settings[low_key]), to_float(settings[high_key]), exponent
            )
        cfg.impact_jerk.exponent = exponent
        cfg.mei_rms.exponent = exponent
        cfg.mei_shock.exponent = exponent
        cfg.rsi_weights = parse_float_list(settings["rsiWeights"], 5)
        cfg.rsi_attack_seconds = to_float(settings["attack"])
        cfg.rsi_decay_seconds = to_float(settings["decay"])
        mei_axis = parse_float_list(settings["meiAxis"], 3)
        cfg.mei_axis_weights = (mei_axis[0], mei_axis[1], mei_axis[2])
        cfg.mei_rms.low, cfg.mei_rms.high = to_float(settings["meiRmsLow"]), to_float(settings["meiRmsHigh"])
        cfg.mei_shock.low, cfg.mei_shock.high = to_float(settings["meiShockLow"]), to_float(settings["meiShockHigh"])
        cfg.mei_duration_tau_hours = to_float(settings["meiTau"])
        mei_weights = parse_float_list(settings["meiCurrentWeights"], 3)
        cfg.mei_current_weights = (mei_weights[0], mei_weights[1], mei_weights[2])
        mei_trip_weights = parse_float_list(settings["meiTripWeights"], 3)
        cfg.mei_trip_weights = (
            mei_trip_weights[0], mei_trip_weights[1], mei_trip_weights[2]
        )
        if hasattr(self, "worker") and self.worker.sensor is not None:
            self.worker.sensor.axis_map = self.axis_map

    def _vector_setting(self, key: str) -> Vector3:
        values = cast(list[object], self.storage.settings()[key])
        return Vector3(to_float(values[0]), to_float(values[1]), to_float(values[2]))

    def _sensor_factory(self) -> MPU6050:
        sensor = MPU6050(
            self.config.i2c_bus,
            self.config.i2c_address,
            self.axis_map,
            self._vector_setting("accelOffset"),
            self._vector_setting("gyroOffset"),
        )
        LOG.info("Connected to %s at I2C 0x%02x", sensor.model, self.config.i2c_address)
        return sensor

    def start(self) -> None:
        self.worker.start()

    def stop(self) -> None:
        self.worker.stop()

    def _sample(self, sample: SensorSample) -> None:
        dt = (sample.timestamp_ns - self.last_sample_ns) / 1_000_000_000 if self.last_sample_ns else 0.005
        self.last_sample_ns = sample.timestamp_ns
        if not 0 < dt <= 0.05:
            self.worker.missed += 1
            dt = 0.005
        orientation = self.orientation_filter.update(
            sample.accel_vessel, sample.gyro, dt, self.algorithm.complementary_alpha
        )
        motion = self.analyzer.update(sample.accel_vessel, orientation.gravity, sample.gyro, dt, self.algorithm)
        rates = max(abs(math.degrees(motion.roll_rate)), abs(math.degrees(motion.pitch_rate)))
        if motion.accel_rms / G0 < self.algorithm.idle_accel_rms_g and rates < self.algorithm.idle_rate_deg_s:
            self.idle_seconds += dt
            if self.idle_seconds >= self.algorithm.idle_seconds:
                self.idle = True
        else:
            self.idle_seconds = 0.0
            self.idle = False
        now_ms = monotonic_ms()
        severity_dt = (
            (sample.timestamp_ns - self.last_severity_ns) / 1_000_000_000
            if self.last_severity_ns else 0.1
        )
        if severity_dt >= 0.1:
            self.last_severity_ns = sample.timestamp_ns
            rsi = self.severity.update(
                motion,
                self.impacts.weighted_per_minute(now_ms),
                severity_dt,
                self.algorithm,
                self.rsi_enabled,
            )
        else:
            rsi = self.severity.state
        mei = self.exposure.update(
            motion.slow,
            dt,
            self.active_trip_id is not None or not self.idle,
            self.algorithm,
            self.mei_enabled,
        )
        impact = self.impacts.update(motion, orientation, rsi.current, now_ms, self.algorithm)
        if impact:
            self.storage.add_impact(impact)
            if self.active_trip_id is not None:
                self.trip.weighted_impacts += impact.severity
                self.trip.impact_counts[0 if impact.severity < 0.33 else 1 if impact.severity < 0.66 else 2] += 1
        if self.active_trip_id is not None:
            self._update_trip(motion, orientation, rsi.current, mei.current, dt)
        self.recent_calibration.append(sample)
        trip_interval_ns = 1_000_000_000 // self.config.trip_sample_hz
        if (
            self.active_trip_id is not None
            and sample.timestamp_ns - self.last_trip_sample_ns >= trip_interval_ns
        ):
            self.last_trip_sample_ns = sample.timestamp_ns
            elapsed_ms = max(
                0, (sample.timestamp_ns - self.active_trip_start_ns) // 1_000_000
            )
            self.storage.add_sample(elapsed_ms, orientation, motion, rsi, mei)
            with self.lock:
                self.state.last_history = (
                    elapsed_ms,
                    round(math.degrees(orientation.display_roll) * 100),
                    round(math.degrees(orientation.display_pitch) * 100),
                    round(motion.fast.x / G0 * 1000),
                    round(motion.fast.y / G0 * 1000),
                    round(motion.fast.z / G0 * 1000),
                )
            if elapsed_ms >= self.config.maximum_trip_seconds * 1000:
                self.storage.end_trip(self.trip)
                self.active_trip_id = None
        self._record_overview(sample.timestamp_ns, now_ms, orientation, motion)
        with self.lock:
            self.state.sample = sample
            self.state.orientation = orientation
            self.state.motion = motion
            self.state.rsi = rsi
            self.state.mei = mei
            self.state.impact = self.impacts.active

    def command(self, value: str) -> None:
        command = value.strip().lower()
        if command == "start":
            self.active_trip_id = self.storage.start_trip(self.algorithm.version)
            active = self.storage.active_trip()
            self.active_trip_start_ms = int(active["start_ms"]) if active else 0
            self.active_trip_start_ns = time.monotonic_ns()
            self.last_trip_sample_ns = self.active_trip_start_ns
            self.trip = TripRuntime(trip_id=self.active_trip_id)
        elif command == "end":
            self.storage.end_trip(self.trip)
            self.active_trip_id = None
            self.active_trip_start_ms = 0
            self.active_trip_start_ns = 0
            self.last_trip_sample_ns = 0
        elif command == "reset":
            with self.lock:
                self.state.reset_sequence += 1
                self.trip.heatmap_seconds = [0.0] * 400
                self.overview_history.clear()
                self.overview_impacts.clear()
                self.overview_impact_active = False
                self.last_overview_sample_ns = 0
        elif command == "zero":
            self.orientation_filter.zero()
            self.storage.update_settings({
                "rollZero": self.orientation_filter.roll_zero,
                "pitchZero": self.orientation_filter.pitch_zero,
            })
        elif command == "calibrate":
            self.calibrate()
        elif command == "defaults":
            self.storage.restore_algorithm_defaults()
            self.apply_settings()
        else:
            raise ValueError("Unknown command")

    def calibrate(self) -> None:
        samples = list(self.recent_calibration)
        if len(samples) < 1000:
            raise RuntimeError("Keep the vessel level and still until 1000 samples are available")
        accel = Vector3(
            *(sum(getattr(sample.accel_uncalibrated, axis) for sample in samples) / len(samples)
              for axis in ("x", "y", "z"))
        )
        gyro = Vector3(
            *(sum(getattr(sample.gyro_uncalibrated, axis) for sample in samples) / len(samples)
              for axis in ("x", "y", "z"))
        )
        expected = [0.0, 0.0, 0.0]
        expected[self.axis_map.source[2]] = self.axis_map.sign[2] * G0
        offset = [accel.x - expected[0], accel.y - expected[1], accel.z - expected[2]]
        self.storage.update_settings({
            "accelOffset": offset,
            "gyroOffset": [gyro.x, gyro.y, gyro.z],
        })
        if self.worker.sensor:
            self.worker.sensor.accel_offset = Vector3(*offset)
            self.worker.sensor.gyro_offset = gyro

    def telemetry(self) -> dict[str, object]:
        with self.lock:
            state = self.state
            sample, orientation, motion = state.sample, state.orientation, state.motion
            return {
                "t": monotonic_ms(),
                "roll": math.degrees(orientation.display_roll),
                "pitch": math.degrees(orientation.display_pitch),
                "raw": vector(sample.accel_sensor if sample else Vector3()),
                "mapped": vector(sample.accel_vessel if sample else Vector3()),
                "gyro": vector(sample.gyro if sample else Vector3()),
                "gravity": vector(orientation.gravity),
                "a": [motion.fast.x / G0, motion.fast.y / G0, motion.fast.z / G0],
                "af": motion.fast_resultant / G0,
                "as": motion.slow_resultant / G0,
                "peak": motion.accel_peak / G0,
                "rms": motion.accel_rms / G0,
                "jerk": motion.jerk_resultant / G0,
                "rates": [math.degrees(motion.roll_rate), math.degrees(motion.pitch_rate)],
                "rsi": {
                    "components": [
                        state.rsi.peak, state.rsi.rms, state.rsi.jerk,
                        state.rsi.angular, state.rsi.repeat,
                    ],
                    "raw": state.rsi.raw, "current": state.rsi.current,
                    "trip": self.trip.rsi_trip,
                },
                "mei": {
                    "rms": state.mei.rms, "shock": state.mei.shock,
                    "dose": state.mei.dose4, "current": state.mei.current,
                    "trip": self.trip.mei_trip,
                },
                "impact": state.impact,
                "trip": self.active_trip_id is not None,
                "tripSeconds": max(
                    0,
                    int((time.monotonic_ns() - self.active_trip_start_ns) / 1_000_000_000),
                ) if self.active_trip_id is not None else 0,
                "tripStartMs": self.active_trip_start_ms if self.active_trip_id is not None else 0,
                "hs": list(state.last_history),
                "reset": state.reset_sequence,
                "sensor": self.worker.online,
                "network": True,
                "timeVerified": True,
                "sampleHz": self.worker.sample_hz_actual,
                "wsHz": self.config.telemetry_hz,
                "errors": self.worker.errors,
                "missed": self.worker.missed,
                "invalid": self.worker.invalid,
            }

    def heatmap_snapshot(self) -> tuple[int, bool, list[float]]:
        with self.lock:
            return (
                self.trip.trip_id,
                self.active_trip_id is not None,
                list(self.trip.heatmap_seconds),
            )

    def overview_snapshot(
        self,
    ) -> tuple[int, list[tuple[int, int, int, int, int, int, int]], list[int]]:
        with self.lock:
            now_ms = monotonic_ms()
            self._compact_overview(now_ms)
            return now_ms, list(self.overview_history), list(self.overview_impacts)

    def _update_trip(
        self,
        motion: Motion,
        orientation: Orientation,
        rsi: float,
        mei: float,
        dt: float,
    ) -> None:
        trip = self.trip
        trip.max_roll = max(trip.max_roll, abs(math.degrees(orientation.display_roll)))
        trip.max_pitch = max(trip.max_pitch, abs(math.degrees(orientation.display_pitch)))
        for index, value in enumerate((motion.fast.x, motion.fast.y, motion.fast.z)):
            trip.max_axis[index] = max(trip.max_axis[index], abs(value))
        trip.max_resultant = max(trip.max_resultant, motion.fast_resultant)
        trip.max_jerk = max(trip.max_jerk, motion.jerk_resultant)
        trip.rsi_sum += rsi
        trip.rsi_updates += 1
        trip.rsi_mean = trip.rsi_sum / trip.rsi_updates
        trip.rsi_max = max(trip.rsi_max, rsi)
        rsi_bin = min(19, max(0, int(rsi * 2)))
        mei_bin = min(19, max(0, int(mei * 2)))
        trip.rsi_histogram[rsi_bin] += 1
        trip.heatmap_seconds[mei_bin * 20 + rsi_bin] += dt
        effective = math.sqrt(sum(
            (weight * value) ** 2
            for weight, value in zip(
                self.algorithm.mei_axis_weights,
                (motion.slow.x, motion.slow.y, motion.slow.z),
            )
        ))
        trip.sum_a2 += effective * effective * dt
        trip.dose4 += effective ** 4 * dt
        trip.exposure_seconds += dt
        target = int(trip.rsi_updates * 0.95)
        total = 0
        for index, count in enumerate(trip.rsi_histogram):
            total += count
            if total >= target:
                trip.rsi_p95 = (index + 0.5) * 0.5
                break
        impacts_per_hour = (
            trip.weighted_impacts * 3600 / trip.exposure_seconds
            if trip.exposure_seconds else 0
        )
        impact_score = normalize(
            impacts_per_hour,
            self.algorithm.trip_impact_per_hour.low,
            self.algorithm.trip_impact_per_hour.high,
            self.algorithm.trip_impact_per_hour.exponent,
        )
        trip.rsi_trip = clamp(sum(
            weight * value
            for weight, value in zip(
                self.algorithm.trip_rsi_weights,
                (trip.rsi_mean, trip.rsi_p95, trip.rsi_max, 10 * impact_score),
            )
        ), 0, 10)
        trip.mei_trip = MotionExposure.score(
            trip.sum_a2, trip.dose4, trip.exposure_seconds, self.algorithm
        )

    def _record_overview(
        self,
        timestamp_ns: int,
        now_ms: int,
        orientation: Orientation,
        motion: Motion,
    ) -> None:
        if self.impacts.active and not self.overview_impact_active:
            self.overview_impacts.append(now_ms)
        self.overview_impact_active = self.impacts.active
        if timestamp_ns - self.last_overview_sample_ns < 2_000_000_000:
            return
        self.last_overview_sample_ns = timestamp_ns
        self.overview_history.append((
            now_ms,
            bounded_int16(math.degrees(orientation.display_roll) * 100),
            bounded_int16(math.degrees(orientation.display_pitch) * 100),
            bounded_int16(motion.fast.x / G0 * 1000),
            bounded_int16(motion.fast.y / G0 * 1000),
            bounded_int16(motion.fast.z / G0 * 1000),
            bounded_int16(motion.fast_resultant / G0 * 1000),
        ))
        self._compact_overview(now_ms)

    def _compact_overview(self, now_ms: int) -> None:
        compacted: deque[tuple[int, int, int, int, int, int, int]] = deque()
        last_kept = 0
        items = list(self.overview_history)
        for index, sample in enumerate(items):
            age = now_ms - sample[0]
            if age > 12 * 60 * 60 * 1000:
                continue
            spacing = 2000 if age <= 10 * 60 * 1000 else 6000 if age <= 60 * 60 * 1000 else 30000 if age <= 6 * 60 * 60 * 1000 else 60000
            if not compacted or sample[0] - last_kept >= spacing or index == len(items) - 1:
                compacted.append(sample)
                last_kept = sample[0]
        self.overview_history = compacted
        while len(self.overview_history) > 1900:
            self.overview_history.popleft()
        while self.overview_impacts and now_ms - self.overview_impacts[0] > 12 * 60 * 60 * 1000:
            self.overview_impacts.popleft()


def vector(value: Vector3) -> list[float]:
    return [value.x, value.y, value.z]


def parse_float_list(value: object, count: int) -> tuple[float, ...]:
    values = tuple(float(item.strip()) for item in str(value).split(","))
    if len(values) != count:
        raise ValueError(f"Expected {count} comma-separated values")
    return values


def to_float(value: object) -> float:
    if not isinstance(value, (str, int, float)):
        raise ValueError("Setting must be numeric")
    return float(value)


def to_int(value: object) -> int:
    if not isinstance(value, (str, int, float)):
        raise ValueError("Setting must be an integer")
    return int(value)
