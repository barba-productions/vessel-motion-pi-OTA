# Vessel Motion Pi

Raspberry Pi 5 vessel-motion monitor using an MPU-6050, a local web dashboard,
one-second trip history, HDMI kiosk display, LAN access, optional Wi-Fi, and
manual application updates.

RSI and MCI/MEI are experimental engineering metrics. They are not scientific,
medical, regulatory, or ISO-compliant measurements.

## Firmware baseline

This port is based specifically on the released WT32-ETH01 firmware v1.1.4 at
commit `d86d934` in the archived ESP32 project. The dashboard assets, filter and
orientation pipeline, RSI, MEI, impact detection, trip scoring, heatmap, and
binary history formats follow that release.

The intentional Raspberry Pi deviations are:

- MPU-6050 access uses Linux I2C while retaining the 200 Hz sample rate;
- trip history is sampled every one second instead of every five seconds;
- trips use RTC-backed timestamp labels while retaining five-trip retention and
  the eight-hour maximum duration;
- WebSocket telemetry uses the same-origin `/ws` endpoint;
- settings include Raspberry Pi timezone, RTC, Wi-Fi, OTA, and kiosk controls;
- trip and settings persistence uses SQLite rather than ESP32 flash records.

ESP32-P4-NANO development assets and behavior are not part of this baseline.

## Architecture

- Python acquisition worker samples the MPU-6050 over I2C at 200 Hz.
- The motion pipeline ports the ESP32 orientation, filtering, RSI, MCI, and
  impact calculations.
- FastAPI serves the dashboard, REST API, and same-origin WebSocket telemetry.
- SQLite stores settings, impacts, and one-second trip samples.
- Trip labels use the RTC-backed start time and selected IANA timezone.
- NetworkManager provides optional Wi-Fi scanning, connection, disconnection,
  and saved-connection removal.
- Cage runs Chromium as a single-application HDMI kiosk.
- The updater contacts GitHub only after the user presses the update button.

The application is offline-first. Ethernet is the primary connection. Internet
access is not required except while performing a manual software update.

## Development

Python 3.11 or newer is required.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
$env:PYTHONPATH = "src"
.\.venv\Scripts\python.exe -m pytest
```

Run a development server:

```powershell
$env:PYTHONPATH = "src"
$env:VESSEL_MOTION_DATA = ".data"
.\.venv\Scripts\python.exe -m vessel_motion --host 127.0.0.1 --port 8080
```

The server remains available with degraded health when I2C is absent. It never
substitutes simulated measurements.

## Raspberry Pi installation

Use a clean Raspberry Pi OS 64-bit installation with I2C enabled. Copy or clone
the repository to a temporary administrative location, then run:

```bash
sudo sh deploy/install.sh
```

The installer creates:

- `vessel-motion`: locked service account that owns application data and releases.
- `vessel-kiosk`: locked HDMI-only account with no access to application releases.
- `vessel-kiosk-control`: narrow shared group for the kiosk unlock signal.
- `/opt/vessel-motion/releases/<version>`: versioned application releases.
- `/opt/vessel-motion/current`: active-release symlink.
- `/var/lib/vessel-motion`: SQLite database and update state.
- `/etc/vessel-motion`: root-controlled application configuration.

The dashboard is served on port 80 and advertised as `vessel-motion.local`.

The commissioned vessel installation uses:

- Ethernet: static `192.168.11.223/24`, no gateway or default route
- Wi-Fi: DHCP, route metric 600, optional internet/update connection

This keeps the direct development-PC LAN deterministic while allowing Wi-Fi to
provide internet access without replacing the primary vessel LAN route.

### Source-code protection

The HDMI browser does not run as the administrative user. The `vessel-kiosk`
account is not a member of the application group and cannot read
`/opt/vessel-motion/releases`, `/etc/vessel-motion`, or `/var/lib/vessel-motion`.
It also has a locked password, no sudo access, and no normal desktop or terminal.

This protects the source from a normal kiosk user. It cannot protect against
someone with physical access who can remove the storage device, boot another
operating system, or obtain the administrator/root password. Full-disk
encryption can mitigate storage removal, but it complicates unattended boot.

### Kiosk maintenance PIN

The initial maintenance PIN is `159`, stored only as a salted PBKDF2-SHA256
hash. Five failed attempts within five minutes are rate limited.

`159` is intentionally supported as requested but is weak. Change it to at
least six digits before commissioning. The PIN only exits the Cage/Chromium
session; it does not grant shell or source-code access. Administrative work
should use a separate SSH-enabled administrator account with key-based login.

When the PIN is accepted, the kiosk service exits successfully and remains
stopped until it is manually started or the Pi reboots:

```bash
sudo systemctl start vessel-motion-kiosk
```

## Time and RTC

The Time settings tab:

- lists IANA timezones;
- changes the system timezone through `timedatectl`;
- allows manual time entry when internet/NTP is unavailable;
- reports whether `/dev/rtc0` exists.

Timestamps are stored in UTC. Trip labels are generated from the start timestamp
using the selected timezone. Raspberry Pi OS synchronizes the RTC and system
clock; the application does not repeatedly write the RTC.

## Wi-Fi management

The application uses `nmcli` and a narrow PolicyKit rule. It can:

- display Wi-Fi status;
- scan access points;
- connect using an SSID and optional password;
- disconnect Wi-Fi;
- remove a saved Wi-Fi connection.

Ethernet remains active while Wi-Fi is managed. Wi-Fi credentials are stored by
NetworkManager, not in the Vessel Motion database.

## Application updates

Application updates are separate from Raspberry Pi OS and EEPROM updates. The
application never checks for updates at startup.

Pressing the update button:

1. downloads the manifest from the public OTA repository;
2. validates product, architecture, version, URL, size, and SHA-256;
3. downloads and validates the archive;
4. rejects unsafe paths, links, and device files;
5. installs into a versioned release directory;
6. atomically switches the `current` symlink;
7. records the previous release for startup rollback.

Create release artifacts with:

```powershell
$env:PYTHONPATH = "src"
.\.venv\Scripts\python.exe scripts\create_release.py 0.1.3
```

The source repository workflow can publish those files to
`barba-productions/vessel-motion-pi-OTA` when the
`OTA_REPOSITORY_TOKEN` GitHub Actions secret is configured.

## Verification

The automated tests cover:

- ESP32 reference orientation and axis-mapping behavior;
- WT32-ETH01 v1.1.4 MEI trip-score behavior and web-asset provenance;
- gravity removal at level, pitch, and roll;
- timestamped one-second trip storage;
- binary trip, live heatmap, and overview-history compatibility;
- PIN hashing and kiosk unlock signaling;
- dashboard, health, REST, and WebSocket behavior;
- OTA URL restrictions and archive path traversal rejection.

Pi commissioning must additionally verify real I2C sampling rate, RTC behavior,
NetworkManager permissions, Cage/Chromium startup, HDMI resolution, and an
interrupted update on the target hardware.
