from __future__ import annotations

from datetime import datetime
from pathlib import Path
import re
import subprocess
from typing import TypedDict
from zoneinfo import available_timezones, ZoneInfo


class WifiNetwork(TypedDict):
    ssid: str
    signal: int
    secure: bool


def run_command(arguments: list[str], timeout: int = 20) -> str:
    completed = subprocess.run(
        arguments,
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if completed.returncode:
        message = completed.stderr.strip() or completed.stdout.strip() or "Command failed"
        raise RuntimeError(message)
    return completed.stdout


class WifiManager:
    def status(self) -> dict[str, object]:
        output = run_command([
            "nmcli", "-t", "-f", "TYPE,STATE,CONNECTION", "device", "status"
        ])
        wifi = next(
            (line.split(":", 2) for line in output.splitlines() if line.startswith("wifi:")),
            ("wifi", "unavailable", ""),
        )
        connected = wifi[1] == "connected"
        details = {"connected": connected, "connecting": wifi[1] == "connecting", "ssid": wifi[2]}
        if connected:
            connection = run_command([
                "nmcli", "-t", "-f", "IP4.ADDRESS,GENERAL.HWADDR",
                "device", "show",
                self._wifi_device(),
            ])
            address = next(
                (line.split(":", 1)[1].split("/", 1)[0] for line in connection.splitlines()
                 if line.startswith("IP4.ADDRESS")),
                "",
            )
            details["ip"] = address
        else:
            details["ip"] = ""
        details["internet"] = False
        return details

    def _wifi_device(self) -> str:
        output = run_command(["nmcli", "-t", "-f", "DEVICE,TYPE", "device", "status"])
        for line in output.splitlines():
            device, device_type = line.split(":", 1)
            if device_type == "wifi":
                return device
        raise RuntimeError("No Wi-Fi adapter is available")

    def scan(self) -> list[WifiNetwork]:
        output = run_command([
            "nmcli", "-t", "--escape", "yes", "-f", "SSID,SIGNAL,SECURITY",
            "device", "wifi", "list", "--rescan", "yes",
        ], timeout=30)
        networks: dict[str, WifiNetwork] = {}
        for line in output.splitlines():
            parts = re.split(r"(?<!\\):", line)
            if len(parts) < 3:
                continue
            ssid = parts[0].replace(r"\:", ":").replace(r"\\", "\\")
            if not ssid:
                continue
            signal = int(parts[1] or 0)
            if ssid not in networks or signal > networks[ssid]["signal"]:
                networks[ssid] = {
                    "ssid": ssid,
                    "signal": signal,
                    "secure": bool(parts[2] and parts[2] != "--"),
                }
        return sorted(networks.values(), key=lambda item: item["signal"], reverse=True)

    def connect(self, ssid: str, password: str) -> None:
        if not 1 <= len(ssid.encode("utf-8")) <= 32:
            raise ValueError("SSID must be between 1 and 32 bytes")
        arguments = ["nmcli", "device", "wifi", "connect", ssid, "ifname", self._wifi_device()]
        if password:
            arguments.extend(("password", password))
        run_command(arguments, timeout=45)

    def disconnect(self) -> None:
        run_command(["nmcli", "device", "disconnect", self._wifi_device()])

    def forget(self, ssid: str = "") -> None:
        if not ssid:
            ssid = str(self.status().get("ssid", ""))
        if not ssid:
            raise ValueError("There is no connected Wi-Fi network to forget")
        run_command(["nmcli", "connection", "delete", "id", ssid])


class ClockManager:
    def timezones(self) -> list[str]:
        return sorted(available_timezones())

    def status(self, timezone_name: str) -> dict[str, object]:
        zone = ZoneInfo(timezone_name)
        now = datetime.now(zone)
        return {
            "timezone": timezone_name,
            "localTime": now.isoformat(timespec="seconds"),
            "current": now.isoformat(timespec="seconds"),
            "lastSync": "RTC",
            "syncing": False,
            "epochMs": int(now.timestamp() * 1000),
            "rtc": Path("/dev/rtc0").exists(),
        }

    def set_timezone(self, timezone_name: str) -> None:
        if timezone_name not in available_timezones():
            raise ValueError("Unknown timezone")
        run_command(["timedatectl", "set-timezone", timezone_name])

    def set_time(self, iso_value: str, timezone_name: str) -> None:
        try:
            value = datetime.fromisoformat(iso_value)
        except ValueError as error:
            raise ValueError("Time must be a valid ISO-8601 value") from error
        if value.tzinfo is None:
            value = value.replace(tzinfo=ZoneInfo(timezone_name))
        run_command(["timedatectl", "set-ntp", "false"])
        run_command(["timedatectl", "set-time", value.strftime("%Y-%m-%d %H:%M:%S")])
