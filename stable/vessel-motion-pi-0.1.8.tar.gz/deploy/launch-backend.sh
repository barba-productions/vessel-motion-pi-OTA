#!/bin/sh
set -eu

current=/opt/vessel-motion/current
rollback=/var/lib/vessel-motion/rollback.json
python=/opt/vessel-motion/venv/bin/python

if ! PYTHONPATH="$current/src" "$python" -m compileall -q "$current/src"; then
  if [ -f "$rollback" ]; then
    previous=$(
      "$python" -c 'import json,sys; print(json.load(open(sys.argv[1]))["previous"] or "")' "$rollback"
    )
    if [ -n "$previous" ] && [ -d "$previous" ]; then
      ln -sfn "$previous" /opt/vessel-motion/current
    fi
  fi
  exit 1
fi

export PYTHONPATH="$current/src"
exec "$python" -m vessel_motion --host 0.0.0.0 --port 80
