(function () {
  "use strict";

  function activate(tabName) {
    document.querySelectorAll(".settings-tabs [data-tab]").forEach(function (button) {
      button.classList.toggle("active", button.dataset.tab === tabName);
    });
    document.querySelectorAll(".tab-panel").forEach(function (panel) {
      panel.classList.toggle("active", panel.dataset.panel === tabName);
    });
    history.replaceState(null, "", "#" + tabName);
  }

  function install() {
    var tabs = document.querySelector(".settings-tabs");
    var firmwareTab = tabs && tabs.querySelector('[data-tab="firmware"]');
    var firmwarePanel = document.querySelector('[data-panel="firmware"]');
    if (!tabs || !firmwareTab || !firmwarePanel || tabs.querySelector('[data-tab="wifi"]')) return;

    var wifiTab = document.createElement("button");
    wifiTab.type = "button";
    wifiTab.className = "regular-only";
    wifiTab.dataset.tab = "wifi";
    wifiTab.textContent = "WI-FI";
    tabs.insertBefore(wifiTab, firmwareTab);

    var wifiPanel = document.createElement("section");
    wifiPanel.className = "tab-panel regular-only";
    wifiPanel.dataset.panel = "wifi";
    wifiPanel.innerHTML = '<div class="panel-grid"></div>';
    firmwarePanel.parentNode.insertBefore(wifiPanel, firmwarePanel);

    var updateConnection = Array.from(firmwarePanel.querySelectorAll(".settings-card")).find(function (card) {
      var heading = card.querySelector("h2");
      return heading && heading.textContent.trim() === "Update connection";
    });
    if (updateConnection) wifiPanel.querySelector(".panel-grid").appendChild(updateConnection);

    var serialButton = document.getElementById("settingsSerial");
    if (serialButton) {
      var serialCard = serialButton.closest(".settings-card");
      if (serialCard) serialCard.remove();
    }

    var storageCard = document.getElementById("clearHistory");
    storageCard = storageCard && storageCard.closest(".settings-card");
    if (storageCard) {
      var description = storageCard.querySelector("p");
      if (description) description.textContent = "Clearing history permanently removes archived trips, charts, heat maps, and impact events.";
    }

    wifiTab.onclick = function () { activate("wifi"); };
    tabs.addEventListener("click", function (event) {
      var button = event.target.closest("[data-tab]");
      if (button && button !== wifiTab) wifiPanel.classList.remove("active");
    });
    if (location.hash === "#wifi") activate("wifi");
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", install); else install();
}());