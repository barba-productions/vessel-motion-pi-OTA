(function () {
  "use strict";

  function activate(name) {
    document.querySelectorAll(".settings-tabs [data-tab]").forEach(function (button) {
      button.classList.toggle("active", button.dataset.tab === name);
    });
    document.querySelectorAll(".tab-panel").forEach(function (panel) {
      panel.classList.toggle("active", panel.dataset.panel === name);
    });
    history.replaceState(null, "", "#" + name);
  }

  function message(node, text, ok) {
    node.textContent = text;
    node.style.color = ok ? "#55e49a" : "#ff8c93";
  }

  function install() {
    var tabs = document.querySelector(".settings-tabs");
    var panels = document.querySelector(".settings-form");
    if (!tabs || !panels || tabs.querySelector('[data-tab="time"]')) return;

    var timeTab = document.createElement("button");
    timeTab.type = "button";
    timeTab.dataset.tab = "time";
    timeTab.textContent = "TIME";
    var firmwareTab = tabs.querySelector('[data-tab="firmware"]');
    tabs.insertBefore(timeTab, firmwareTab);

    var panel = document.createElement("section");
    panel.className = "tab-panel regular-only";
    panel.dataset.panel = "time";
    panel.innerHTML =
      '<div class="panel-grid">' +
      '<div class="settings-card wide"><h2>Time and timezone</h2>' +
      '<p>The Raspberry Pi RTC preserves the clock while power is off. Trip timestamps are stored in UTC and displayed in the selected timezone.</p>' +
      '<label class="field"><span>Timezone<small>Used for dashboard and trip labels</small></span><select id="piTimezone"></select></label>' +
      '<label class="field"><span>Set date and time<small>ISO-8601 value including UTC offset</small></span><input id="piLocalTime" type="datetime-local" step="1"></label>' +
      '<div class="action-row"><button class="settings-action" id="savePiTime" type="button">APPLY TIME SETTINGS</button></div>' +
      '<p id="piTimeStatus"></p></div>' +
      '<div class="settings-card wide"><h2>Kiosk maintenance</h2>' +
      '<p>Exiting the HDMI kiosk requires the maintenance PIN. The initial PIN is 159 and should be changed before commissioning.</p>' +
      '<label class="field"><span>Maintenance PIN</span><input id="maintenancePin" type="password" inputmode="numeric" autocomplete="off"></label>' +
      '<div class="action-row"><button class="settings-action danger" id="unlockKiosk" type="button">EXIT KIOSK</button></div>' +
      '<p id="kioskStatus"></p></div></div>';
    panels.appendChild(panel);

    timeTab.onclick = function () { activate("time"); };
    Promise.all([
      fetch("/api/timezones").then(function (response) { return response.json(); }),
      fetch("/api/time").then(function (response) { return response.json(); })
    ]).then(function (result) {
      var select = document.getElementById("piTimezone");
      result[0].timezones.forEach(function (zone) {
        var option = document.createElement("option");
        option.value = option.textContent = zone;
        option.selected = zone === result[1].timezone;
        select.appendChild(option);
      });
      document.getElementById("piLocalTime").value = result[1].localTime.slice(0, 19);
      message(document.getElementById("piTimeStatus"), "RTC " + (result[1].rtc ? "detected" : "not detected"), result[1].rtc);
    }).catch(function (error) {
      message(document.getElementById("piTimeStatus"), error.message, false);
    });

    document.getElementById("savePiTime").onclick = function () {
      var zone = document.getElementById("piTimezone").value;
      var local = document.getElementById("piLocalTime").value;
      fetch("/api/time", {
        method: "PUT",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({timezone: zone, localTime: local})
      }).then(function (response) {
        if (!response.ok) return response.json().then(function (data) { throw new Error(data.detail || "Time update failed"); });
        return response.json();
      }).then(function () {
        message(document.getElementById("piTimeStatus"), "Time settings applied", true);
      }).catch(function (error) {
        message(document.getElementById("piTimeStatus"), error.message, false);
      });
    };

    document.getElementById("unlockKiosk").onclick = function () {
      fetch("/api/maintenance/unlock", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({pin: document.getElementById("maintenancePin").value})
      }).then(function (response) {
        if (!response.ok) return response.json().then(function (data) { throw new Error(data.detail || "Unlock failed"); });
        message(document.getElementById("kioskStatus"), "Kiosk session is closing", true);
      }).catch(function (error) {
        message(document.getElementById("kioskStatus"), error.message, false);
      });
    };

    if (location.hash === "#time") activate("time");
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", install);
  else install();
}());
