#!/bin/sh
set -eu

if [ "$(id -u)" -ne 0 ]; then
  echo "Run this installer as root." >&2
  exit 1
fi

source_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
version=$(
  PYTHONPATH="$source_dir/src" python3 -c 'from vessel_motion import __version__; print(__version__)'
)
release="/opt/vessel-motion/releases/$version"

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  python3 python3-venv chromium cage curl network-manager polkitd acl rpi-connect \
  avahi-daemon

getent group vessel-kiosk-control >/dev/null || groupadd --system vessel-kiosk-control
id vessel-motion >/dev/null 2>&1 || useradd --system --home /var/lib/vessel-motion --shell /usr/sbin/nologin vessel-motion
id vessel-kiosk >/dev/null 2>&1 || useradd --system --create-home --home-dir /home/vessel-kiosk --shell /usr/sbin/nologin vessel-kiosk
usermod -a -G i2c,vessel-kiosk-control vessel-motion
usermod -a -G video,render,input,vessel-kiosk-control vessel-kiosk

install -d -o vessel-motion -g vessel-motion -m 0750 /opt/vessel-motion
install -d -o vessel-motion -g vessel-motion -m 0750 /opt/vessel-motion/releases
install -d -o vessel-motion -g vessel-motion -m 0750 /var/lib/vessel-motion
install -d -o root -g vessel-motion -m 0750 /etc/vessel-motion
install -d -o root -g root -m 0755 /usr/local/lib/vessel-motion
rm -rf "$release"
install -d -o vessel-motion -g vessel-motion -m 0750 "$release"
cp -a "$source_dir/src" "$source_dir/web" "$source_dir/pyproject.toml" "$source_dir/requirements.txt" "$release/"
chown -R vessel-motion:vessel-motion "$release"
if [ -e /opt/vessel-motion/current ] && [ ! -L /opt/vessel-motion/current ]; then
  mv /opt/vessel-motion/current "/opt/vessel-motion/current.legacy.$(date +%s)"
fi
ln -sfnT "$release" /opt/vessel-motion/current

if [ ! -d /opt/vessel-motion/venv ]; then
  python3 -m venv /opt/vessel-motion/venv
fi
/opt/vessel-motion/venv/bin/pip install --disable-pip-version-check -r "$release/requirements.txt"

install -o root -g vessel-motion -m 0640 "$source_dir/config/vessel-motion.toml" /etc/vessel-motion/vessel-motion.toml
install -o root -g root -m 0644 "$source_dir/deploy/systemd/vessel-motion.service" /etc/systemd/system/vessel-motion.service
install -o root -g root -m 0644 "$source_dir/deploy/systemd/vessel-motion-kiosk.service" /etc/systemd/system/vessel-motion-kiosk.service
install -o root -g root -m 0755 "$source_dir/deploy/launch-kiosk.sh" /usr/local/lib/vessel-motion/launch-kiosk.sh
install -o root -g root -m 0755 "$source_dir/deploy/launch-backend.sh" /usr/local/lib/vessel-motion/launch-backend.sh
install -o root -g root -m 0755 "$source_dir/deploy/expose-kiosk-wayland.sh" /usr/local/lib/vessel-motion/expose-kiosk-wayland.sh
install -o root -g root -m 0644 "$source_dir/deploy/polkit/50-vessel-motion.rules" /etc/polkit-1/rules.d/50-vessel-motion.rules
install -o root -g root -m 0644 "$source_dir/deploy/avahi/vessel-motion.service" /etc/avahi/services/vessel-motion.service

if id vessel >/dev/null 2>&1; then
  loginctl enable-linger vessel
fi

if ! nmcli -g NAME connection show | grep -Fxq vessel-motion-fallback-ap; then
  nmcli connection add type wifi ifname '*' con-name vessel-motion-fallback-ap ssid Vessel-Motion
fi
nmcli connection modify vessel-motion-fallback-ap \
  connection.autoconnect yes \
  connection.autoconnect-priority -999 \
  802-11-wireless.mode ap \
  802-11-wireless.band bg \
  ipv4.method shared \
  ipv4.addresses 192.168.4.1/24 \
  ipv6.method disabled \
  wifi-sec.key-mgmt wpa-psk \
  wifi-sec.psk vessel-motion

systemctl disable --now getty@tty1.service 2>/dev/null || true
systemctl disable --now display-manager.service 2>/dev/null || true
systemctl daemon-reload
systemctl enable --now vessel-motion.service
systemctl enable --now vessel-motion-kiosk.service

echo "Vessel Motion $version installed."
echo "Dashboard: http://$(hostname -I | awk '{print $1}')/"
