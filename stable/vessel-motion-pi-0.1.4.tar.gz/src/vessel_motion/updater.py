from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import tarfile
import threading
import time
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from . import __version__
from .config import AppConfig


@dataclass
class UpdateStatus:
    state: str = "idle"
    currentVersion: str = __version__
    availableVersion: str = ""
    message: str = "Ready"
    received: int = 0
    total: int = 0
    progress: int = 0


class UpdateManager:
    ALLOWED_HOST = "raw.githubusercontent.com"
    ALLOWED_PATH = "/barba-productions/vessel-motion-pi-OTA/"

    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.status = UpdateStatus()
        self.lock = threading.Lock()
        self.thread: threading.Thread | None = None

    def snapshot(self) -> dict[str, object]:
        with self.lock:
            return asdict(self.status)

    def start(self) -> bool:
        with self.lock:
            if self.thread and self.thread.is_alive():
                return False
            self.status = UpdateStatus(state="checking", message="Connecting to update server")
            self.thread = threading.Thread(target=self._run, name="manual-update", daemon=True)
            self.thread.start()
            return True

    def _set(self, **values: object) -> None:
        with self.lock:
            for key, value in values.items():
                setattr(self.status, key, value)

    def _request(self, url: str, timeout: int = 20):
        return urlopen(Request(url, headers={"User-Agent": "Vessel-Motion-Pi-Updater"}), timeout=timeout)

    def _validate_url(self, url: str) -> None:
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname != self.ALLOWED_HOST or not parsed.path.startswith(self.ALLOWED_PATH):
            raise ValueError("Update URL is outside the approved OTA repository")

    def _run(self) -> None:
        try:
            self._validate_url(self.config.ota_manifest_url)
            with self._request(self.config.ota_manifest_url) as response:
                manifest = json.load(response)
            required = {"schema", "product", "version", "architecture", "url", "size", "sha256"}
            if not required.issubset(manifest):
                raise ValueError("Update manifest is incomplete")
            if manifest["schema"] != 1 or manifest["product"] != "vessel-motion-pi":
                raise ValueError("Update manifest is for a different product")
            expected_arch = "aarch64" if platform.machine() in ("aarch64", "arm64") else platform.machine()
            if manifest["architecture"] != expected_arch:
                raise ValueError("Update package architecture does not match this Pi")
            version = str(manifest["version"])
            if not re.fullmatch(r"\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?", version):
                raise ValueError("Update version is invalid")
            self._set(availableVersion=version)
            if version == __version__:
                self._set(state="current", message="The installed version is current")
                return
            url = str(manifest["url"])
            self._validate_url(url)
            expected_size = int(manifest["size"])
            expected_hash = str(manifest["sha256"]).lower()
            if expected_size <= 0 or not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
                raise ValueError("Update size or SHA-256 is invalid")
            self._set(state="downloading", total=expected_size, message="Downloading update")
            self.config.data_dir.mkdir(parents=True, exist_ok=True)
            archive = self.config.data_dir / f"vessel-motion-{version}.tar.gz.part"
            digest, received = hashlib.sha256(), 0
            with self._request(url, timeout=60) as response, archive.open("wb") as output:
                while block := response.read(128 * 1024):
                    output.write(block)
                    digest.update(block)
                    received += len(block)
                    self._set(received=received, progress=min(100, received * 100 // expected_size))
            if received != expected_size or digest.hexdigest() != expected_hash:
                archive.unlink(missing_ok=True)
                raise ValueError("Downloaded update failed size or SHA-256 verification")
            release = self.config.ota_releases_dir / version
            stage = release.with_name(release.name + ".staging")
            if stage.exists():
                self._remove_tree(stage)
            stage.mkdir(parents=True)
            with tarfile.open(archive, "r:gz") as package:
                self._safe_extract(package, stage)
            archive.unlink(missing_ok=True)
            if not (stage / "pyproject.toml").is_file() or not (stage / "src" / "vessel_motion").is_dir():
                raise ValueError("Update archive does not contain a Vessel Motion application")
            if release.exists():
                self._remove_tree(release)
            stage.replace(release)
            previous = self.config.ota_current_link.resolve() if self.config.ota_current_link.exists() else None
            temporary_link = self.config.ota_current_link.with_name("current.new")
            temporary_link.unlink(missing_ok=True)
            temporary_link.symlink_to(release, target_is_directory=True)
            temporary_link.replace(self.config.ota_current_link)
            rollback = self.config.data_dir / "rollback.json"
            rollback.write_text(json.dumps({
                "previous": str(previous) if previous else None,
                "installed": str(release),
                "installedAt": int(time.time() * 1000),
            }), encoding="utf-8")
            self._set(state="complete", progress=100, message="Update installed; restart required")
            time.sleep(1)
            os._exit(75)
        except Exception as error:
            self._set(state="failed", message=str(error))

    @staticmethod
    def _safe_extract(package: tarfile.TarFile, destination: Path) -> None:
        root = destination.resolve()
        members = package.getmembers()
        for member in members:
            target = (destination / member.name).resolve()
            if root != target and root not in target.parents:
                raise ValueError("Update archive contains an unsafe path")
            if member.issym() or member.islnk() or member.isdev():
                raise ValueError("Update archive contains an unsupported link or device")
        package.extractall(destination, members=members)

    @staticmethod
    def _remove_tree(path: Path) -> None:
        for directory, directories, _ in os.walk(path):
            os.chmod(directory, 0o700)
            for child in directories:
                os.chmod(Path(directory) / child, 0o700)
        shutil.rmtree(path)
