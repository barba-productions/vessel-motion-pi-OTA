from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import csv
import hashlib
import hmac
import io
import json
from pathlib import Path
import secrets
import sqlite3
import struct
import threading
from typing import Generator
from zoneinfo import ZoneInfo

from .motion import Impact, Motion, Orientation, Severity, Exposure

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS trips (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    start_ms INTEGER NOT NULL,
    end_ms INTEGER,
    timezone TEXT NOT NULL,
    label TEXT NOT NULL,
    algorithm_version INTEGER NOT NULL,
    duration_seconds INTEGER NOT NULL DEFAULT 0,
    sample_count INTEGER NOT NULL DEFAULT 0,
    max_roll REAL NOT NULL DEFAULT 0,
    max_pitch REAL NOT NULL DEFAULT 0,
    max_resultant_g REAL NOT NULL DEFAULT 0,
    rsi_sum REAL NOT NULL DEFAULT 0,
    rsi_max REAL NOT NULL DEFAULT 0,
    rsi_trip REAL NOT NULL DEFAULT 0,
    mei_sum REAL NOT NULL DEFAULT 0,
    mei_trip REAL NOT NULL DEFAULT 0,
    completed INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS trip_samples (
    trip_id INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
    elapsed_ms INTEGER NOT NULL,
    roll REAL NOT NULL,
    pitch REAL NOT NULL,
    ax REAL NOT NULL,
    ay REAL NOT NULL,
    az REAL NOT NULL,
    resultant REAL NOT NULL,
    rsi REAL NOT NULL,
    mei REAL NOT NULL,
    PRIMARY KEY (trip_id, elapsed_ms)
);
CREATE TABLE IF NOT EXISTS impacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id INTEGER REFERENCES trips(id) ON DELETE CASCADE,
    epoch_ms INTEGER NOT NULL,
    elapsed_ms INTEGER NOT NULL,
    duration_ms INTEGER NOT NULL,
    peak_x REAL NOT NULL,
    peak_y REAL NOT NULL,
    peak_z REAL NOT NULL,
    peak_resultant_g REAL NOT NULL,
    peak_jerk_g REAL NOT NULL,
    roll REAL NOT NULL,
    pitch REAL NOT NULL,
    rsi REAL NOT NULL,
    severity REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS impacts_trip_id ON impacts(trip_id);
CREATE TABLE IF NOT EXISTS update_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    version TEXT NOT NULL,
    attempted_ms INTEGER NOT NULL,
    status TEXT NOT NULL,
    message TEXT NOT NULL
);
"""

DEFAULT_SETTINGS: dict[str, object] = {
    "vessel": "Vessel",
    "hostname": "vessel-motion",
    "timezone": "UTC",
    "metric": True,
    "rsi": True,
    "mei": True,
    "fullscreen": True,
    "productName": "VESSEL MOTION",
    "productSize": 2,
    "uiFont": 0,
    "colorScheme": 0,
    "vesselView": "aft",
    "vesselModel": "original",
    "reloadOnTab": True,
    "axisSource": [0, 1, 2],
    "axisSign": [1, -1, 1],
    "axisX": 1,
    "axisY": 2,
    "axisZ": 3,
    "accelOffset": [0.0, 0.0, 0.0],
    "gyroOffset": [0.0, 0.0, 0.0],
    "rollZero": 0.0,
    "pitchZero": 0.0,
    "dhcp": True,
    "wifiAuto": True,
    "garminRefresh": 20,
    "alpha": 0.98,
    "fast": 25.0,
    "slow": 4.0,
    "derivative": 12.0,
    "impactStart": 0.25,
    "impactEnd": 0.15,
    "impactEndMs": 100,
    "impactDeadbandMs": 150,
    "peakLow": 0.10,
    "peakHigh": 1.50,
    "rmsLow": 0.03,
    "rmsHigh": 0.50,
    "jerkLow": 0.5,
    "jerkHigh": 15.0,
    "rollLow": 2.0,
    "rollHigh": 25.0,
    "pitchLow": 2.0,
    "pitchHigh": 25.0,
    "repeatLow": 1.0,
    "repeatHigh": 20.0,
    "impactLow": 0.25,
    "impactHigh": 1.50,
    "exponent": 2.0,
    "rsiWeights": "0.35,0.25,0.20,0.10,0.10",
    "attack": 0.20,
    "decay": 5.0,
    "meiAxis": "1,1,1",
    "meiRmsLow": 0.02,
    "meiRmsHigh": 0.30,
    "meiShockLow": 0.03,
    "meiShockHigh": 0.50,
    "meiTau": 4.0,
    "meiCurrentWeights": "0.45,0.35,0.20",
    "meiTripWeights": "0.40,0.40,0.20",
    "originalScale": 100,
    "originalVertical": 0,
    "originalElevation": 0,
    "originalYaw": 0,
    "tugScale": 100,
    "tugVertical": 0,
    "tugElevation": 0,
    "tugYaw": 0,
    "yachtScale": 100,
    "yachtVertical": 0,
    "yachtElevation": 0,
    "yachtYaw": 0,
}


class Storage:
    def __init__(self, directory: Path, retention: int = 5) -> None:
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / "vessel-motion.sqlite3"
        self.retention = retention
        self.local = threading.local()
        with self.connection() as db:
            db.executescript(SCHEMA)
            db.executemany(
                "INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)",
                ((key, json.dumps(value)) for key, value in DEFAULT_SETTINGS.items()),
            )
            if db.execute("SELECT 1 FROM settings WHERE key='maintenancePin'").fetchone() is None:
                self._set_pin(db, "159")

    @contextmanager
    def connection(self) -> Generator[sqlite3.Connection, None, None]:
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        finally:
            db.close()

    def settings(self) -> dict[str, object]:
        with self.connection() as db:
            return {
                row["key"]: json.loads(row["value"])
                for row in db.execute("SELECT key,value FROM settings")
                if row["key"] != "maintenancePin"
            }

    def update_settings(self, values: dict[str, object]) -> None:
        allowed = set(DEFAULT_SETTINGS)
        unknown = set(values) - allowed
        if unknown:
            raise ValueError(f"Unsupported settings: {', '.join(sorted(unknown))}")
        if "timezone" in values:
            ZoneInfo(str(values["timezone"]))
        with self.connection() as db:
            db.executemany(
                "INSERT INTO settings(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                ((key, json.dumps(value)) for key, value in values.items()),
            )

    def _set_pin(self, db: sqlite3.Connection, pin: str) -> None:
        if not pin.isdigit() or not 3 <= len(pin) <= 12:
            raise ValueError("Maintenance PIN must contain 3 to 12 digits")
        salt = secrets.token_bytes(16)
        digest = hashlib.pbkdf2_hmac("sha256", pin.encode(), salt, 310_000)
        value = f"pbkdf2-sha256$310000${salt.hex()}${digest.hex()}"
        db.execute(
            "INSERT INTO settings(key,value) VALUES('maintenancePin',?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(value),),
        )

    def set_pin(self, old_pin: str, new_pin: str) -> None:
        if not self.verify_pin(old_pin):
            raise PermissionError("Current maintenance PIN is incorrect")
        with self.connection() as db:
            self._set_pin(db, new_pin)

    def verify_pin(self, pin: str) -> bool:
        with self.connection() as db:
            row = db.execute("SELECT value FROM settings WHERE key='maintenancePin'").fetchone()
        if row is None:
            return False
        algorithm, rounds, salt, expected = json.loads(row["value"]).split("$")
        if algorithm != "pbkdf2-sha256":
            return False
        actual = hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), int(rounds))
        return hmac.compare_digest(actual, bytes.fromhex(expected))

    def start_trip(self, algorithm_version: int = 1) -> int:
        settings = self.settings()
        zone_name = str(settings["timezone"])
        now = datetime.now(timezone.utc)
        label = now.astimezone(ZoneInfo(zone_name)).strftime("%Y-%m-%d %H:%M:%S %Z")
        with self.connection() as db:
            active = db.execute("SELECT id FROM trips WHERE completed=0").fetchone()
            if active:
                return int(active["id"])
            cursor = db.execute(
                "INSERT INTO trips(start_ms,timezone,label,algorithm_version) VALUES(?,?,?,?)",
                (int(now.timestamp() * 1000), zone_name, label, algorithm_version),
            )
            if cursor.lastrowid is None:
                raise RuntimeError("SQLite did not allocate a trip identifier")
            return cursor.lastrowid

    def end_trip(self) -> None:
        with self.connection() as db:
            row = db.execute("SELECT id,start_ms FROM trips WHERE completed=0").fetchone()
            if row is None:
                return
            now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
            db.execute(
                "UPDATE trips SET end_ms=?,duration_seconds=(?-start_ms)/1000,"
                "rsi_trip=CASE WHEN sample_count>0 THEN rsi_sum/sample_count ELSE 0 END,"
                "mei_trip=CASE WHEN sample_count>0 THEN mei_sum/sample_count ELSE 0 END,"
                "completed=1 WHERE id=?",
                (now_ms, now_ms, row["id"]),
            )
            obsolete = db.execute(
                "SELECT id FROM trips WHERE completed=1 ORDER BY start_ms DESC LIMIT -1 OFFSET ?",
                (self.retention,),
            ).fetchall()
            db.executemany("DELETE FROM trips WHERE id=?", ((item["id"],) for item in obsolete))

    def active_trip(self) -> sqlite3.Row | None:
        with self.connection() as db:
            return db.execute("SELECT * FROM trips WHERE completed=0").fetchone()

    def add_sample(
        self, orientation: Orientation, motion: Motion, rsi: Severity, mei: Exposure
    ) -> None:
        with self.connection() as db:
            trip = db.execute("SELECT id,start_ms FROM trips WHERE completed=0").fetchone()
            if trip is None:
                return
            now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
            elapsed = now_ms - int(trip["start_ms"])
            db.execute(
                "INSERT OR REPLACE INTO trip_samples VALUES(?,?,?,?,?,?,?,?,?,?)",
                (
                    trip["id"], elapsed, math_degrees(orientation.display_roll),
                    math_degrees(orientation.display_pitch), motion.fast.x / 9.80665,
                    motion.fast.y / 9.80665, motion.fast.z / 9.80665,
                    motion.fast_resultant / 9.80665, rsi.current, mei.current,
                ),
            )
            db.execute(
                "UPDATE trips SET duration_seconds=?/1000,sample_count=sample_count+1,"
                "max_roll=max(max_roll,abs(?)),max_pitch=max(max_pitch,abs(?)),"
                "max_resultant_g=max(max_resultant_g,?),rsi_sum=rsi_sum+?,"
                "rsi_max=max(rsi_max,?),mei_sum=mei_sum+? WHERE id=?",
                (
                    elapsed, math_degrees(orientation.display_roll),
                    math_degrees(orientation.display_pitch), motion.fast_resultant / 9.80665,
                    rsi.current, rsi.current, mei.current, trip["id"],
                ),
            )

    def add_impact(self, impact: Impact) -> None:
        with self.connection() as db:
            trip = db.execute("SELECT id,start_ms FROM trips WHERE completed=0").fetchone()
            now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
            start_ms = int(trip["start_ms"]) if trip else now_ms
            db.execute(
                "INSERT INTO impacts(trip_id,epoch_ms,elapsed_ms,duration_ms,peak_x,peak_y,"
                "peak_z,peak_resultant_g,peak_jerk_g,roll,pitch,rsi,severity)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    trip["id"] if trip else None, now_ms, max(0, now_ms - start_ms),
                    impact.duration_ms, impact.peak.x / 9.80665, impact.peak.y / 9.80665,
                    impact.peak.z / 9.80665, impact.peak_resultant / 9.80665,
                    impact.peak_jerk / 9.80665, math_degrees(impact.roll),
                    math_degrees(impact.pitch), impact.rsi, impact.severity,
                ),
            )

    def list_trips(self) -> list[dict[str, object]]:
        with self.connection() as db:
            rows = db.execute(
                "SELECT * FROM trips WHERE completed=1 ORDER BY start_ms DESC"
            ).fetchall()
        return [
            {
                "id": row["id"], "label": row["label"], "startMs": row["start_ms"],
                "timeVerified": True, "durationSeconds": row["duration_seconds"],
                "samples": row["sample_count"], "rsiTrip": row["rsi_trip"],
                "meiTrip": row["mei_trip"],
            }
            for row in rows
        ]

    def trip_detail(self, trip_id: int) -> dict[str, object] | None:
        with self.connection() as db:
            trip = db.execute("SELECT * FROM trips WHERE id=?", (trip_id,)).fetchone()
            if trip is None:
                return None
            impacts = db.execute(
                "SELECT elapsed_ms,severity,peak_resultant_g FROM impacts WHERE trip_id=?",
                (trip_id,),
            ).fetchall()
            samples = db.execute(
                "SELECT roll,pitch FROM trip_samples WHERE trip_id=?", (trip_id,)
            ).fetchall()
        heatmap = [0.0] * 400
        for sample in samples:
            x = max(0, min(19, int((sample["roll"] + 45) / 4.5)))
            y = max(0, min(19, int((sample["pitch"] + 45) / 4.5)))
            heatmap[y * 20 + x] += 1.0
        counts = [0, 0, 0]
        for impact in impacts:
            counts[min(2, int(impact["severity"] * 3))] += 1
        return {
            "id": trip["id"], "label": trip["label"], "durationSeconds": trip["duration_seconds"],
            "samples": trip["sample_count"], "headerBytes": 0,
            "algorithmVersion": trip["algorithm_version"], "maxRoll": trip["max_roll"],
            "maxPitch": trip["max_pitch"], "maxAxisG": [0, 0, 0],
            "maxResultantG": trip["max_resultant_g"], "maxJerkG": 0,
            "rsiMean": trip["rsi_trip"], "rsiMax": trip["rsi_max"], "rsiP95": 0,
            "rsiTrip": trip["rsi_trip"], "meiTrip": trip["mei_trip"],
            "impactCounts": counts, "impactMarkers": [
                {"elapsedMs": row["elapsed_ms"], "severity": row["severity"], "peakG": row["peak_resultant_g"]}
                for row in impacts
            ], "heatmap": heatmap,
        }

    def trip_samples_binary(self, trip_id: int) -> bytes | None:
        with self.connection() as db:
            exists = db.execute("SELECT 1 FROM trips WHERE id=?", (trip_id,)).fetchone()
            if not exists:
                return None
            rows = db.execute(
                "SELECT * FROM trip_samples WHERE trip_id=? ORDER BY elapsed_ms", (trip_id,)
            ).fetchall()
        return b"".join(
            struct.pack(
                "<Ihhhhhh",
                row["elapsed_ms"],
                bounded_int16(row["roll"] * 100),
                bounded_int16(row["pitch"] * 100),
                bounded_int16(row["ax"] * 1000),
                bounded_int16(row["ay"] * 1000),
                bounded_int16(row["az"] * 1000),
                bounded_int16(row["resultant"] * 1000),
            )
            for row in rows
        )

    def clear_history(self) -> bool:
        with self.connection() as db:
            if db.execute("SELECT 1 FROM trips WHERE completed=0").fetchone():
                return False
            db.execute("DELETE FROM trips")
            db.execute("DELETE FROM impacts")
        return True

    def trips_csv(self) -> str:
        output = io.StringIO(newline="")
        writer = csv.writer(output)
        writer.writerow([
            "trip_id", "start_utc", "end_utc", "timezone", "label", "duration_s",
            "samples", "rsi_trip", "mei_trip", "max_roll_deg", "max_pitch_deg",
            "max_resultant_g",
        ])
        with self.connection() as db:
            rows = db.execute("SELECT * FROM trips ORDER BY start_ms").fetchall()
        for row in rows:
            writer.writerow([
                row["id"], epoch_iso(row["start_ms"]), epoch_iso(row["end_ms"]),
                row["timezone"], row["label"], row["duration_seconds"], row["sample_count"],
                row["rsi_trip"], row["mei_trip"], row["max_roll"], row["max_pitch"],
                row["max_resultant_g"],
            ])
        return output.getvalue()

    def impacts_csv(self) -> str:
        output = io.StringIO(newline="")
        writer = csv.writer(output)
        writer.writerow([
            "trip_id", "timestamp_utc", "elapsed_ms", "duration_ms", "peak_x_g",
            "peak_y_g", "peak_z_g", "peak_resultant_g", "peak_jerk_g_s",
            "roll_deg", "pitch_deg", "rsi", "severity",
        ])
        with self.connection() as db:
            rows = db.execute("SELECT * FROM impacts ORDER BY epoch_ms").fetchall()
        for row in rows:
            writer.writerow([
                row["trip_id"], epoch_iso(row["epoch_ms"]), row["elapsed_ms"],
                row["duration_ms"], row["peak_x"], row["peak_y"], row["peak_z"],
                row["peak_resultant_g"], row["peak_jerk_g"], row["roll"], row["pitch"],
                row["rsi"], row["severity"],
            ])
        return output.getvalue()


def math_degrees(value: float) -> float:
    return value * 180.0 / 3.141592653589793


def bounded_int16(value: float) -> int:
    return max(-32768, min(32767, round(value)))


def epoch_iso(epoch_ms: int | None) -> str:
    if epoch_ms is None:
        return ""
    return datetime.fromtimestamp(epoch_ms / 1000, timezone.utc).isoformat(
        timespec="milliseconds"
    ).replace("+00:00", "Z")
