#!/bin/sh
set -eu

unlock=/run/vessel-motion/kiosk-unlock
rm -f "$unlock"

until /usr/bin/curl --fail --silent --max-time 2 http://127.0.0.1/health >/dev/null; do
  sleep 1
done

/usr/bin/chromium \
  --kiosk \
  --no-first-run \
  --disable-session-crashed-bubble \
  --disable-infobars \
  --disable-features=Translate \
  --overscroll-history-navigation=0 \
  --password-store=basic \
  --user-data-dir="$HOME/.config/vessel-motion-chromium" \
  http://127.0.0.1/ &
browser=$!

trap 'kill "$browser" 2>/dev/null || true' INT TERM EXIT
while kill -0 "$browser" 2>/dev/null; do
  if [ -f "$unlock" ]; then
    rm -f "$unlock"
    kill "$browser" 2>/dev/null || true
    wait "$browser" 2>/dev/null || true
    trap - INT TERM EXIT
    exit 0
  fi
  sleep 1
done

wait "$browser"
