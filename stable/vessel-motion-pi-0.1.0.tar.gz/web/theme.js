// Preview defaults; the ESP32 previously generated this endpoint dynamically.
window.vmUiSettings = {
  productName: "VESSEL MOTION", productSize: 2, uiFont: 0,
  colorScheme: 0, timezone: "America/New_York", fullscreen: true,
  vessel: "PI 5 HDMI PREVIEW", vesselModel: "original"
};
