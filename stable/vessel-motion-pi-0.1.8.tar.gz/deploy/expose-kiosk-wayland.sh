#!/bin/sh
set -eu

connect_user=${1:-vessel}
kiosk_user=${2:-vessel-kiosk}

if ! id "$connect_user" >/dev/null 2>&1 || ! id "$kiosk_user" >/dev/null 2>&1; then
  exit 0
fi

connect_uid=$(id -u "$connect_user")
kiosk_uid=$(id -u "$kiosk_user")
connect_runtime="/run/user/$connect_uid"
kiosk_runtime="/run/user/$kiosk_uid"
kiosk_socket="$kiosk_runtime/wayland-0"

attempt=0
while [ ! -S "$kiosk_socket" ] && [ "$attempt" -lt 50 ]; do
  sleep 0.1
  attempt=$((attempt + 1))
done

if [ ! -S "$kiosk_socket" ] || [ ! -d "$connect_runtime" ]; then
  exit 0
fi

setfacl -m "u:$connect_user:--x" "$kiosk_runtime"
setfacl -m "u:$connect_user:rw" "$kiosk_socket"
ln -sfn "$kiosk_socket" "$connect_runtime/wayland-0"
chown -h "$connect_user:$connect_user" "$connect_runtime/wayland-0"
