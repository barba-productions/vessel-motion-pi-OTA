from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import tomllib


@dataclass(frozen=True)
class AppConfig:
    data_dir: Path
    web_dir: Path
    i2c_bus: int = 1
    i2c_address: int = 0x68
    sample_hz: int = 200
    telemetry_hz: int = 50
    trip_sample_hz: int = 5
    maximum_trip_seconds: int = 8 * 60 * 60
    trip_retention: int = 5
    ota_manifest_url: str = (
        "https://raw.githubusercontent.com/barba-productions/"
        "vessel-motion-pi-OTA/main/stable/manifest.json"
    )
    ota_releases_dir: Path = Path("/opt/vessel-motion/releases")
    ota_current_link: Path = Path("/opt/vessel-motion/current")
    kiosk_unlock_file: Path = Path("/run/vessel-motion/kiosk-unlock")


def load_config(path: str | Path | None = None) -> AppConfig:
    workspace = Path(__file__).resolve().parents[2]
    defaults = {
        "data_dir": os.environ.get("VESSEL_MOTION_DATA", str(workspace / ".data")),
        "web_dir": os.environ.get("VESSEL_MOTION_WEB", str(workspace / "web")),
    }
    config_path = Path(path or os.environ.get(
        "VESSEL_MOTION_CONFIG", "/etc/vessel-motion/vessel-motion.toml"
    ))
    values: dict[str, object] = {}
    if config_path.is_file():
        values = tomllib.loads(config_path.read_text(encoding="utf-8")).get("app", {})
    if values.get("telemetry_hz") == 20:
        values["telemetry_hz"] = 50
    merged = {**defaults, **values}
    for key in ("data_dir", "web_dir", "ota_releases_dir", "ota_current_link", "kiosk_unlock_file"):
        if key in merged:
            merged[key] = Path(str(merged[key]))
    return AppConfig(**merged)
