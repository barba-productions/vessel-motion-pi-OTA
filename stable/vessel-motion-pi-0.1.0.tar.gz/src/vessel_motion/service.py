from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
import logging
import math
import threading
from typing import cast

from .config import AppConfig
from .motion import (
    AlgorithmConfig,
    AxisMap,
    Exposure,
    G0,
    ImpactDetector,
    Motion,
    MotionAnalyzer,
    MotionExposure,
    Orientation,
    OrientationFilter,
    RideSeverity,
    Severity,
    Vector3,
    monotonic_ms,
)
from .sensor import MPU6050, SensorSample, SensorWorker
from .storage import Storage

LOG = logging.getLogger(__name__)


@dataclass(slots=True)
class RuntimeState:
    sample: SensorSample | None = None
    orientation: Orientation = field(default_factory=Orientation)
    motion: Motion = field(default_factory=Motion)
    rsi: Severity = field(default_factory=Severity)
    mei: Exposure = field(default_factory=Exposure)
    impact: bool = False
    reset_sequence: int = 0
    last_history: tuple[int, int, int, int, int, int] = (0, 0, 0, 0, 0, 0)


class VesselMotionService:
    def __init__(self, config: AppConfig, storage: Storage) -> None:
        self.config, self.storage = config, storage
        self.algorithm = AlgorithmConfig()
        self.orientation_filter = OrientationFilter()
        self.analyzer = MotionAnalyzer()
        self.severity = RideSeverity()
        self.exposure = MotionExposure()
        self.impacts = ImpactDetector()
        self.state = RuntimeState()
        self.lock = threading.RLock()
        self.last_sample_ns = 0
        self.last_severity_ns = 0
        self.last_trip_sample_ns = 0
        self.recent_calibration: deque[SensorSample] = deque(maxlen=1000)
        active_trip = storage.active_trip()
        self.active_trip_id = int(active_trip["id"]) if active_trip else None
        self.active_trip_start_ms = int(active_trip["start_ms"]) if active_trip else 0
        settings = storage.settings()
        axis_source = cast(list[object], settings["axisSource"])
        axis_sign = cast(list[object], settings["axisSign"])
        self.axis_map = AxisMap(
            (to_int(axis_source[0]), to_int(axis_source[1]), to_int(axis_source[2])),
            (to_int(axis_sign[0]), to_int(axis_sign[1]), to_int(axis_sign[2])),
        )
        self.orientation_filter.roll_zero = to_float(settings["rollZero"])
        self.orientation_filter.pitch_zero = to_float(settings["pitchZero"])
        self.apply_settings(settings)
        self.worker = SensorWorker(self._sensor_factory, config.sample_hz, self._sample)

    def apply_settings(self, settings: dict[str, object] | None = None) -> None:
        settings = settings or self.storage.settings()
        axis_values = [to_int(settings.get(name, default)) for name, default in (
            ("axisX", 1), ("axisY", 2), ("axisZ", 3)
        )]
        if all(1 <= abs(value) <= 3 for value in axis_values) and len(
            {abs(value) for value in axis_values}
        ) == 3:
            mounting_sign = (1, -1, 1)
            sources = tuple(abs(value) - 1 for value in axis_values)
            signs = tuple(
                (1 if value > 0 else -1) * mounting_sign[source]
                for value, source in zip(axis_values, sources)
            )
            self.axis_map = AxisMap(
                (sources[0], sources[1], sources[2]),
                (signs[0], signs[1], signs[2]),
            )
        cfg = self.algorithm
        cfg.complementary_alpha = to_float(settings["alpha"])
        cfg.fast_cutoff_hz = to_float(settings["fast"])
        cfg.slow_cutoff_hz = to_float(settings["slow"])
        cfg.derivative_cutoff_hz = to_float(settings["derivative"])
        cfg.impact_start_g = to_float(settings["impactStart"])
        cfg.impact_end_g = to_float(settings["impactEnd"])
        cfg.impact_end_ms = to_int(settings["impactEndMs"])
        cfg.impact_deadband_ms = to_int(settings["impactDeadbandMs"])
        exponent = to_float(settings["exponent"])
        for target, low_key, high_key in (
            (cfg.peak, "peakLow", "peakHigh"), (cfg.rms, "rmsLow", "rmsHigh"),
            (cfg.jerk, "jerkLow", "jerkHigh"), (cfg.roll_rate, "rollLow", "rollHigh"),
            (cfg.pitch_rate, "pitchLow", "pitchHigh"), (cfg.repeat, "repeatLow", "repeatHigh"),
            (cfg.impact_accel, "impactLow", "impactHigh"),
        ):
            target.low, target.high, target.exponent = (
                to_float(settings[low_key]), to_float(settings[high_key]), exponent
            )
        cfg.rsi_weights = parse_float_list(settings["rsiWeights"], 5)
        cfg.rsi_attack_seconds = to_float(settings["attack"])
        cfg.rsi_decay_seconds = to_float(settings["decay"])
        mei_axis = parse_float_list(settings["meiAxis"], 3)
        cfg.mei_axis_weights = (mei_axis[0], mei_axis[1], mei_axis[2])
        cfg.mei_rms.low, cfg.mei_rms.high = to_float(settings["meiRmsLow"]), to_float(settings["meiRmsHigh"])
        cfg.mei_shock.low, cfg.mei_shock.high = to_float(settings["meiShockLow"]), to_float(settings["meiShockHigh"])
        cfg.mei_duration_tau_hours = to_float(settings["meiTau"])
        mei_weights = parse_float_list(settings["meiCurrentWeights"], 3)
        cfg.mei_current_weights = (mei_weights[0], mei_weights[1], mei_weights[2])
        if hasattr(self, "worker") and self.worker.sensor is not None:
            self.worker.sensor.axis_map = self.axis_map

    def _vector_setting(self, key: str) -> Vector3:
        values = cast(list[object], self.storage.settings()[key])
        return Vector3(to_float(values[0]), to_float(values[1]), to_float(values[2]))

    def _sensor_factory(self) -> MPU6050:
        sensor = MPU6050(
            self.config.i2c_bus,
            self.config.i2c_address,
            self.axis_map,
            self._vector_setting("accelOffset"),
            self._vector_setting("gyroOffset"),
        )
        LOG.info("Connected to %s at I2C 0x%02x", sensor.model, self.config.i2c_address)
        return sensor

    def start(self) -> None:
        self.worker.start()

    def stop(self) -> None:
        self.worker.stop()

    def _sample(self, sample: SensorSample) -> None:
        dt = (sample.timestamp_ns - self.last_sample_ns) / 1_000_000_000 if self.last_sample_ns else 0.005
        self.last_sample_ns = sample.timestamp_ns
        if not 0 < dt <= 0.05:
            self.worker.missed += 1
            dt = 0.005
        orientation = self.orientation_filter.update(
            sample.accel_vessel, sample.gyro, dt, self.algorithm.complementary_alpha
        )
        motion = self.analyzer.update(sample.accel_vessel, orientation.gravity, sample.gyro, dt, self.algorithm)
        now_ms = monotonic_ms()
        severity_dt = (
            (sample.timestamp_ns - self.last_severity_ns) / 1_000_000_000
            if self.last_severity_ns else 0.1
        )
        if severity_dt >= 0.1:
            self.last_severity_ns = sample.timestamp_ns
            rsi = self.severity.update(
                motion, self.impacts.weighted_per_minute(now_ms), severity_dt, self.algorithm
            )
        else:
            rsi = self.severity.state
        mei = self.exposure.update(motion.slow, dt, self.active_trip_id is not None, self.algorithm)
        impact = self.impacts.update(motion, orientation, rsi.current, now_ms, self.algorithm)
        if impact:
            self.storage.add_impact(impact)
        self.recent_calibration.append(sample)
        if self.active_trip_id is not None and sample.timestamp_ns - self.last_trip_sample_ns >= 1_000_000_000:
            self.last_trip_sample_ns = sample.timestamp_ns
            self.storage.add_sample(orientation, motion, rsi, mei)
            elapsed_ms = int(
                datetime.now(timezone.utc).timestamp() * 1000 - self.active_trip_start_ms
            )
            with self.lock:
                self.state.last_history = (
                    elapsed_ms,
                    round(math.degrees(orientation.display_roll) * 100),
                    round(math.degrees(orientation.display_pitch) * 100),
                    round(motion.fast.x / G0 * 1000),
                    round(motion.fast.y / G0 * 1000),
                    round(motion.fast.z / G0 * 1000),
                )
            if elapsed_ms >= self.config.maximum_trip_seconds * 1000:
                self.storage.end_trip()
                self.active_trip_id = None
        with self.lock:
            self.state.sample = sample
            self.state.orientation = orientation
            self.state.motion = motion
            self.state.rsi = rsi
            self.state.mei = mei
            self.state.impact = self.impacts.active

    def command(self, value: str) -> None:
        command = value.strip().lower()
        if command == "start":
            self.active_trip_id = self.storage.start_trip(self.algorithm.version)
            active = self.storage.active_trip()
            self.active_trip_start_ms = int(active["start_ms"]) if active else 0
        elif command == "end":
            self.storage.end_trip()
            self.active_trip_id = None
            self.active_trip_start_ms = 0
        elif command == "reset":
            with self.lock:
                self.state.reset_sequence += 1
        elif command == "zero":
            self.orientation_filter.zero()
            self.storage.update_settings({
                "rollZero": self.orientation_filter.roll_zero,
                "pitchZero": self.orientation_filter.pitch_zero,
            })
        elif command == "calibrate":
            self.calibrate()
        elif command == "defaults":
            self.algorithm = AlgorithmConfig()
        else:
            raise ValueError("Unknown command")

    def calibrate(self) -> None:
        samples = list(self.recent_calibration)
        if len(samples) < 1000:
            raise RuntimeError("Keep the vessel level and still until 1000 samples are available")
        accel = Vector3(
            *(sum(getattr(sample.accel_sensor, axis) for sample in samples) / len(samples)
              for axis in ("x", "y", "z"))
        )
        mapped_gyro = Vector3(
            *(sum(getattr(sample.gyro, axis) for sample in samples) / len(samples)
              for axis in ("x", "y", "z"))
        )
        mapped_values = (mapped_gyro.x, mapped_gyro.y, mapped_gyro.z)
        raw_gyro = [0.0, 0.0, 0.0]
        orientation = self.axis_map.determinant()
        for vessel_axis, source_axis in enumerate(self.axis_map.source):
            raw_gyro[source_axis] = mapped_values[vessel_axis] / (
                orientation * self.axis_map.sign[vessel_axis]
            )
        gyro = Vector3(*raw_gyro)
        expected = [0.0, 0.0, 0.0]
        expected[self.axis_map.source[2]] = self.axis_map.sign[2] * G0
        offset = [accel.x - expected[0], accel.y - expected[1], accel.z - expected[2]]
        self.storage.update_settings({
            "accelOffset": offset,
            "gyroOffset": [gyro.x, gyro.y, gyro.z],
        })
        if self.worker.sensor:
            self.worker.sensor.accel_offset = Vector3(*offset)
            self.worker.sensor.gyro_offset = gyro

    def telemetry(self) -> dict[str, object]:
        with self.lock:
            state = self.state
            sample, orientation, motion = state.sample, state.orientation, state.motion
            return {
                "t": monotonic_ms(),
                "roll": math.degrees(orientation.display_roll),
                "pitch": math.degrees(orientation.display_pitch),
                "raw": vector(sample.accel_sensor if sample else Vector3()),
                "mapped": vector(sample.accel_vessel if sample else Vector3()),
                "gyro": vector(sample.gyro if sample else Vector3()),
                "gravity": vector(orientation.gravity),
                "a": [motion.fast.x / G0, motion.fast.y / G0, motion.fast.z / G0],
                "af": motion.fast_resultant / G0,
                "as": motion.slow_resultant / G0,
                "peak": motion.accel_peak / G0,
                "rms": motion.accel_rms / G0,
                "jerk": motion.jerk_resultant / G0,
                "rates": [math.degrees(motion.roll_rate), math.degrees(motion.pitch_rate)],
                "rsi": {
                    "components": [
                        state.rsi.peak, state.rsi.rms, state.rsi.jerk,
                        state.rsi.angular, state.rsi.repeat,
                    ],
                    "raw": state.rsi.raw, "current": state.rsi.current,
                    "trip": 0,
                },
                "mei": {
                    "rms": state.mei.rms, "shock": state.mei.shock,
                    "dose": state.mei.dose4, "current": state.mei.current,
                    "trip": 0,
                },
                "impact": state.impact,
                "trip": self.active_trip_id is not None,
                "tripSeconds": max(
                    0,
                    int((datetime.now(timezone.utc).timestamp() * 1000 - self.active_trip_start_ms) / 1000),
                ) if self.active_trip_id is not None else 0,
                "hs": list(state.last_history),
                "reset": state.reset_sequence,
                "sensor": self.worker.online,
                "network": True,
                "timeVerified": True,
                "sampleHz": self.worker.sample_hz_actual,
                "wsHz": self.config.telemetry_hz,
                "errors": self.worker.errors,
                "missed": self.worker.missed,
                "invalid": self.worker.invalid,
            }


def vector(value: Vector3) -> list[float]:
    return [value.x, value.y, value.z]


def parse_float_list(value: object, count: int) -> tuple[float, ...]:
    values = tuple(float(item.strip()) for item in str(value).split(","))
    if len(values) != count:
        raise ValueError(f"Expected {count} comma-separated values")
    return values


def to_float(value: object) -> float:
    if not isinstance(value, (str, int, float)):
        raise ValueError("Setting must be numeric")
    return float(value)


def to_int(value: object) -> int:
    if not isinstance(value, (str, int, float)):
        raise ValueError("Setting must be an integer")
    return int(value)
