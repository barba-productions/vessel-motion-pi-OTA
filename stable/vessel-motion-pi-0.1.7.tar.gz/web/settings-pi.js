(function () {
  "use strict";

  function activate(name) {
    document.querySelectorAll(".settings-tabs [data-tab]").forEach(function (button) {
      button.classList.toggle("active", button.dataset.tab === name);
    });
    document.querySelectorAll(".tab-panel").forEach(function (panel) {
      panel.classList.toggle("active", panel.dataset.panel === name);
    });
    history.replaceState(null, "", "#" + name);
  }

  function message(node, text, ok) {
    node.textContent = text;
    node.style.color = ok ? "#55e49a" : "#ff8c93";
  }

  function cardWithHeading(text) {
    return Array.from(document.querySelectorAll(".settings-card")).find(function (card) {
      var heading = card.querySelector("h2");
      return heading && heading.textContent.trim() === text;
    });
  }

  function enableCard(card) {
    card.querySelectorAll("input,select,button").forEach(function (control) {
      control.disabled = false;
    });
  }

  function organizeSettings(tabs, panels) {
    var networkTab = tabs.querySelector('[data-tab="network"]');
    var motionTab = tabs.querySelector('[data-tab="motion"]');
    var motionPanel = panels.querySelector('[data-panel="motion"]');
    var vesselTab = document.createElement("button");
    var vesselPanel = document.createElement("section");
    var vesselCard = cardWithHeading("Vessel identity");
    var axisCard = cardWithHeading("Axis mapping");
    var calibrationCard = cardWithHeading("Calibration");

    vesselTab.type = "button";
    vesselTab.className = "regular-only";
    vesselTab.dataset.tab = "vessel";
    vesselTab.textContent = "VESSEL";
    tabs.insertBefore(vesselTab, networkTab);

    vesselPanel.className = "tab-panel regular-only";
    vesselPanel.dataset.panel = "vessel";
    vesselPanel.innerHTML = '<div class="panel-grid"></div>';
    panels.appendChild(vesselPanel);
    vesselPanel.querySelector(".panel-grid").appendChild(vesselCard);

    motionTab.className = "regular-only";
    motionPanel.className = "tab-panel regular-only";
    tabs.insertBefore(motionTab, networkTab);
    motionPanel.querySelector(".panel-grid").prepend(axisCard, calibrationCard);
    [vesselCard, axisCard, calibrationCard, motionPanel].forEach(enableCard);

    var vertical = document.getElementById("modelVertical");
    vertical.min = "-100";
    vertical.max = "100";
    vertical.step = "1";
    vertical.closest("label").querySelector("small").textContent = "-100 to +100";
    vertical.setAttribute("inputmode", "numeric");

    var style = document.createElement("style");
    style.textContent = ".form-footer .save{font-size:26px!important}";
    document.head.appendChild(style);
    vesselTab.onclick = function () { activate("vessel"); };
  }

  function install() {
    var tabs = document.querySelector(".settings-tabs");
    var panels = document.querySelector(".settings-form");
    if (!tabs || !panels || tabs.querySelector('[data-tab="time"]')) return;
    organizeSettings(tabs, panels);

    var timeTab = document.createElement("button");
    timeTab.type = "button";
    timeTab.dataset.tab = "time";
    timeTab.textContent = "TIME";
    var firmwareTab = tabs.querySelector('[data-tab="firmware"]');
    tabs.insertBefore(timeTab, firmwareTab);

    var panel = document.createElement("section");
    panel.className = "tab-panel regular-only";
    panel.dataset.panel = "time";
    panel.innerHTML =
      '<div class="panel-grid">' +
      '<div class="settings-card wide"><h2>Time and timezone</h2>' +
      '<p>The Raspberry Pi RTC preserves the clock while power is off. Trip timestamps are stored in UTC and displayed in the selected timezone.</p>' +
      '<label class="field"><span>Timezone<small>Used for dashboard and trip labels</small></span><select id="piTimezone"></select></label>' +
      '<label class="field"><span>Time format<small>Used for trip names and dashboard times</small></span><select id="piTimeFormat"><option value="24">24-hour</option><option value="12">12-hour (AM/PM)</option></select></label>' +
      '<label class="field"><span>Date format<small>Used for trip names</small></span><select id="piDateFormat"><option value="mdy">MM/DD/YY</option><option value="dmy">DD/MM/YY</option></select></label>' +
      '<label class="field"><span>Set date and time<small>ISO-8601 value including UTC offset</small></span><input id="piLocalTime" type="datetime-local" step="1"></label>' +
      '<div class="action-row"><button class="settings-action" id="savePiTime" type="button">APPLY TIME SETTINGS</button></div>' +
      '<p id="piTimeStatus"></p></div>' +
      '<div class="settings-card wide"><h2>Kiosk maintenance</h2>' +
      '<p>Exiting the HDMI kiosk requires the maintenance PIN. The initial PIN is 159 and should be changed before commissioning.</p>' +
      '<label class="field"><span>Hide mouse cursor in kiosk mode</span><select id="hideKioskCursor"><option value="true">YES</option><option value="false">NO</option></select></label>' +
      '<label class="field"><span>Maintenance PIN</span><input id="maintenancePin" type="password" inputmode="numeric" autocomplete="off"></label>' +
      '<div class="action-row"><button class="settings-action danger" id="unlockKiosk" type="button">EXIT KIOSK</button></div>' +
      '<p id="kioskStatus"></p></div></div>';
    panels.appendChild(panel);

    timeTab.onclick = function () { activate("time"); };
    Promise.all([
      fetch("/api/timezones").then(function (response) { return response.json(); }),
      fetch("/api/time").then(function (response) { return response.json(); }),
      fetch("/api/settings").then(function (response) { return response.json(); })
    ]).then(function (result) {
      var select = document.getElementById("piTimezone");
      result[0].timezones.forEach(function (zone) {
        var option = document.createElement("option");
        option.value = option.textContent = zone;
        option.selected = zone === result[1].timezone;
        select.appendChild(option);
      });
      document.getElementById("piLocalTime").value = result[1].localTime.slice(0, 19);
      document.getElementById("piTimeFormat").value = result[2].timeFormat || "24";
      document.getElementById("piDateFormat").value = result[2].dateFormat || "mdy";
      document.getElementById("hideKioskCursor").value = result[2].hideKioskCursor === false ? "false" : "true";
      message(document.getElementById("piTimeStatus"), "RTC " + (result[1].rtc ? "detected" : "not detected"), result[1].rtc);
    }).catch(function (error) {
      message(document.getElementById("piTimeStatus"), error.message, false);
    });

    document.getElementById("savePiTime").onclick = function () {
      var zone = document.getElementById("piTimezone").value;
      var local = document.getElementById("piLocalTime").value;
      var formats = {
        timeFormat: document.getElementById("piTimeFormat").value,
        dateFormat: document.getElementById("piDateFormat").value,
        hideKioskCursor: document.getElementById("hideKioskCursor").value === "true"
      };
      Promise.all([
        fetch("/api/time", {
          method: "PUT",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({timezone: zone, localTime: local})
        }),
        fetch("/api/settings", {
          method: "PATCH",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify(formats)
        })
      ]).then(function (responses) {
        return Promise.all(responses.map(function (response) {
          if (!response.ok) return response.json().then(function (data) { throw new Error(data.detail || "Time update failed"); });
          return response.json();
        }));
      }).then(function () {
        message(document.getElementById("piTimeStatus"), "Time settings applied", true);
      }).catch(function (error) {
        message(document.getElementById("piTimeStatus"), error.message, false);
      });
    };

    document.getElementById("unlockKiosk").onclick = function () {
      fetch("/api/maintenance/unlock", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({pin: document.getElementById("maintenancePin").value})
      }).then(function (response) {
        if (!response.ok) return response.json().then(function (data) { throw new Error(data.detail || "Unlock failed"); });
        message(document.getElementById("kioskStatus"), "Kiosk session is closing", true);
      }).catch(function (error) {
        message(document.getElementById("kioskStatus"), error.message, false);
      });
    };

    if (/^#(vessel|motion|time)$/.test(location.hash)) activate(location.hash.slice(1));
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", install);
  else install();
}());
