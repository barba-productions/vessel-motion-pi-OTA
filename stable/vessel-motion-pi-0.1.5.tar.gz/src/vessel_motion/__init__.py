"""Vessel Motion Raspberry Pi application."""

__version__ = "0.1.5"
